# SCALPER/X — Forex Scalping Bot

A full-stack MERN trading dashboard implementing an **EMA 9/21 crossover + Stochastic Oscillator** scalping strategy with real-time analysis, auto-execution (paper trading by default), risk management, backtesting, and a neon glassmorphism UI.

> ⚠️ **Educational software.** It ships with a built-in simulated market feed and a paper-trading engine. Connecting it to a live broker and real funds is entirely at your own risk. Trading leveraged FX can cause rapid loss of capital. This is not financial advice.

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, Vite, Tailwind CSS, Recharts, TradingView widget |
| Backend | Node.js, Express, WebSocket (`ws`) |
| Database | MongoDB + Mongoose |
| Auth | JWT (bcrypt-hashed passwords) |
| Real-time | WebSocket push (ticks, candles, signals, trade events) |
| Deploy | Docker + docker-compose, nginx |

---

## Strategy Logic

**BUY** when *all* are true on the latest closed candle:
- EMA(9) crosses **above** EMA(21)
- Stochastic %K crosses **above** %D
- Momentum emerging from the **oversold** zone

**SELL** when:
- EMA(9) crosses **below** EMA(21)
- Stochastic %K crosses **below** %D
- Momentum coming out of the **overbought** zone

Each trade gets pip-based Take Profit / Stop Loss, optional trailing stop, and is sized by your risk settings. The **same `evaluateStrategy()` function powers both live trading and the backtester**, so results stay consistent.

---

## Project Structure

```
forex-scalping-bot/
├── docker-compose.yml
├── .env.example
├── server/                 # Node + Express + WS API
│   ├── src/
│   │   ├── index.js              # entry: REST + WS + feed + engine
│   │   ├── config/db.js, seed.js
│   │   ├── models/               # User, Trade, Settings
│   │   ├── middleware/           # JWT auth, error handler
│   │   ├── routes/               # all REST endpoints
│   │   ├── controllers/          # auth, trades, settings, backtest
│   │   ├── services/
│   │   │   ├── indicators.js      # EMA, Stochastic (pure math)
│   │   │   ├── strategy.js        # signal evaluation
│   │   │   ├── marketFeed.js      # sim feed + AlphaVantage hook
│   │   │   ├── tradingEngine.js   # auto-execution + risk mgmt
│   │   │   ├── backtest.js        # historical simulation
│   │   │   └── notify.js          # Telegram + email alerts
│   │   └── ws/socket.js          # websocket server
│   └── Dockerfile
└── client/                 # React + Tailwind dashboard
    ├── src/
    │   ├── pages/                # Login, Register, Dashboard
    │   ├── components/           # chart, widgets, panels
    │   ├── context/AuthContext   # JWT session
    │   ├── hooks/useSocket       # live data
    │   └── api/client            # axios + token interceptor
    ├── Dockerfile + nginx.conf
    └── vite.config.js
```

---

## Quick Start (Docker — recommended)

```bash
cp .env.example .env          # set JWT_SECRET
docker compose up --build
```

- Dashboard: http://localhost:8080
- API:       http://localhost:5000/api/health

Seed a demo admin (in another terminal):
```bash
docker compose exec server npm run seed
# login: admin@scalper.x / admin123
```

## Local Development (no Docker)

**1. MongoDB** — run locally or use Atlas, set `MONGO_URI`.

**2. Backend**
```bash
cd server
cp .env.example .env          # set MONGO_URI + JWT_SECRET
npm install
npm run seed                  # optional demo admin
npm run dev                   # http://localhost:5000
```

**3. Frontend**
```bash
cd client
npm install
npm run dev                   # http://localhost:5173
```
Vite proxies `/api` and `/ws` to the backend automatically.

---

## Market Data Modes (`FEED_MODE` in server/.env)

| Mode | Description | Keys |
|------|-------------|------|
| `sim` (default) | Built-in geometric-Brownian tick engine. No keys, works offline. | none |
| `alphavantage` | Polls Alpha Vantage 1-min FX bars. | `ALPHA_VANTAGE_KEY` |

**Going live with a broker:** implement `executeBrokerOrder()` in `tradingEngine.js` (OANDA / Binance / MT5 bridge) and a `start<Provider>()` method in `marketFeed.js` that calls `pushCandle()`. All downstream logic is unchanged. Browser CORS means broker calls must go through the backend.

---

## REST API

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/register` | — | Create account |
| POST | `/api/auth/login` | — | Get JWT |
| GET | `/api/auth/me` | ✓ | Current user |
| POST | `/api/auth/bot` | ✓ | Toggle auto-trading |
| GET | `/api/market/pairs` | — | Supported pairs |
| GET | `/api/market/:pair/history` | — | Candle history |
| GET | `/api/trades` | ✓ | Trade list |
| GET | `/api/trades/analytics` | ✓ | Stats + equity curve |
| POST | `/api/trades/:id/close` | ✓ | Manual close |
| GET/PUT | `/api/settings` | ✓ | Strategy + risk config |
| POST | `/api/backtest` | ✓ | Run backtest |
| GET | `/api/admin/users` | admin | List users |
| GET | `/api/admin/stats` | admin | Platform stats |

**WebSocket** `ws://host/ws?token=<JWT>` emits: `tick`, `candle`, `signal`, `trade:open`, `trade:close`.

---

## Risk Management

Configurable per user in **Strategy & Risk Controls**:
- Adjustable lot size & risk %
- Take profit / stop loss (pips)
- Dynamic trailing stop
- Max concurrent open trades
- Daily loss limit (halts the bot when breached)
- Auto-close losing trades

---

## Notifications (optional)

Set in `server/.env`:
- **Telegram:** `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`
- **Email:** `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `ALERT_EMAIL_TO`

Missing config = silently skipped, app still runs.

---

## VPS Deployment

```bash
git clone <your-repo> && cd forex-scalping-bot
cp .env.example .env && nano .env     # set a strong JWT_SECRET
docker compose up -d --build
```
Put nginx/Caddy + TLS in front of port 8080 for HTTPS. Use a managed MongoDB (Atlas) for production durability.

---

## License

MIT — provided as-is, without warranty. You are responsible for compliance with your broker's and jurisdiction's regulations.
