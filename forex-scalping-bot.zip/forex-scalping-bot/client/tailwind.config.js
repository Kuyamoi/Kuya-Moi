/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        neon: { blue: "#00d4ff", cyan: "#22f0ff", yellow: "#ffe600", green: "#2bffac", red: "#ff3b6b" },
        ink: { 900: "#05070f", 800: "#0a0e1a", 700: "#0f1525", 600: "#161d33" },
      },
      fontFamily: {
        display: ["'Orbitron'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      boxShadow: {
        neon: "0 0 20px rgba(0,212,255,.35)",
        "neon-y": "0 0 20px rgba(255,230,0,.3)",
      },
      backdropBlur: { xs: "2px" },
    },
  },
  plugins: [],
};
