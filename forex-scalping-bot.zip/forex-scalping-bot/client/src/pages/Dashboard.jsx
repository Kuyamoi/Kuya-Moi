import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { useSocket } from "../hooks/useSocket.js";
import api from "../api/client.js";
import Card from "../components/Card.jsx";
import StatWidget from "../components/StatWidget.jsx";
import MarketOverview from "../components/MarketOverview.jsx";
import SignalsPanel from "../components/SignalsPanel.jsx";
import TradesTable from "../components/TradesTable.jsx";
import StrategySettings from "../components/StrategySettings.jsx";
import BacktestPanel from "../components/BacktestPanel.jsx";
import TradingViewChart from "../components/TradingViewChart.jsx";
import {
  Activity, Power, LogOut, Zap, Radio, Wallet, Target,
  BarChart3, Settings as Cog, History, Crosshair, FlaskConical,
} from "lucide-react";

const PAIRS = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CHF", "USD/CAD"];

export default function Dashboard() {
  const { user, logout, toggleBot } = useAuth();
  const { connected, ticks, signals } = useSocket();
  const [pair, setPair] = useState("EUR/USD");
  const [trades, setTrades] = useState([]);
  const [stats, setStats] = useState(null);
  const [settings, setSettings] = useState(null);

  const refresh = async () => {
    const [t, a, s] = await Promise.all([
      api.get("/trades"), api.get("/trades/analytics"), api.get("/settings"),
    ]);
    setTrades(t.data); setStats(a.data); setSettings(s.data);
  };

  useEffect(() => { refresh(); }, []);
  // Refresh trades/stats whenever a new signal arrives (a trade may have opened)
  useEffect(() => { if (signals.length) refresh(); /* eslint-disable-next-line */ }, [signals.length]);
  useEffect(() => { const id = setInterval(refresh, 8000); return () => clearInterval(id); }, []);

  return (
    <div className="min-h-screen grid-bg bg-ink-900 text-white">
      {/* Top bar */}
      <header className="sticky top-0 z-20 glass border-b border-neon-blue/10 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-neon-blue to-neon-cyan grid place-items-center shadow-neon">
            <Zap className="text-ink-900" size={18} />
          </div>
          <div>
            <div className="font-display text-lg tracking-wider">SCALPER<span className="text-neon-blue">/</span>X</div>
            <div className="text-[10px] text-neon-cyan/50 tracking-widest hidden sm:block">EMA 9/21 × STOCHASTIC ENGINE</div>
          </div>
        </div>
        <div className="flex items-center gap-2 sm:gap-3">
          <span className={`flex items-center gap-1.5 text-[11px] px-2.5 py-1 rounded-full border ${connected ? "border-neon-green/40 text-neon-green" : "border-neon-red/40 text-neon-red"}`}>
            <Radio size={12} className={connected ? "pulse-neon" : ""} /> {connected ? "LIVE" : "OFFLINE"}
          </span>
          <button onClick={() => toggleBot(!user.botEnabled)}
            className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-lg transition ${
              user.botEnabled ? "bg-neon-green text-ink-900 shadow-neon" : "bg-ink-700 text-white/70 border border-white/10"}`}>
            <Power size={14} /> {user.botEnabled ? "BOT ON" : "BOT OFF"}
          </button>
          <button onClick={logout} className="text-white/50 hover:text-neon-red transition p-1.5"><LogOut size={18} /></button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto p-4 sm:p-6 space-y-4">
        {/* Stat row */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          <StatWidget label="ACCOUNT BALANCE" value={`$${(stats?.balance ?? user.balance).toLocaleString()}`} />
          <StatWidget label="NET P/L" value={`$${stats?.netPnl ?? 0}`} tone={(stats?.netPnl ?? 0) >= 0 ? "up" : "down"} />
          <StatWidget label="WIN RATE" value={`${stats?.winRate ?? 0}%`} sub={`${stats?.wins ?? 0}W / ${stats?.losses ?? 0}L`} />
          <StatWidget label="TOTAL PIPS" value={stats?.totalPips ?? 0} tone={(stats?.totalPips ?? 0) >= 0 ? "up" : "down"} />
          <StatWidget label="OPEN TRADES" value={stats?.openTrades ?? 0} sub={`${stats?.totalTrades ?? 0} total`} />
        </div>

        <div className="grid lg:grid-cols-3 gap-4">
          {/* Left/main column */}
          <div className="lg:col-span-2 space-y-4">
            <Card title="LIVE CANDLESTICK CHART" icon={<Activity size={14} />}>
              <TradingViewChart pair={pair} />
            </Card>

            <Card title="LIVE MARKET OVERVIEW" icon={<BarChart3 size={14} />}>
              <MarketOverview pairs={PAIRS} ticks={ticks} active={pair} onSelect={setPair} />
            </Card>

            <Card title="RECENT TRADES" icon={<History size={14} />}>
              <TradesTable trades={trades} />
            </Card>
          </div>

          {/* Right column */}
          <div className="space-y-4">
            <Card title="ACTIVE SIGNALS" icon={<Crosshair size={14} />}>
              <SignalsPanel signals={signals} />
            </Card>

            <Card title="STRATEGY & RISK CONTROLS" icon={<Cog size={14} />}>
              {settings && <StrategySettings settings={settings} onSaved={setSettings} />}
            </Card>

            <Card title="BACKTESTING" icon={<FlaskConical size={14} />} accent="y">
              {settings && <BacktestPanel pair={pair} settings={settings} />}
            </Card>
          </div>
        </div>

        <footer className="text-center text-white/25 text-xs py-4">
          SCALPER/X · Paper-trading engine with simulated feed by default. Configure a broker API + market feed in <code>server/.env</code> to trade live.
          Educational use only — trading carries substantial risk.
        </footer>
      </main>
    </div>
  );
}
