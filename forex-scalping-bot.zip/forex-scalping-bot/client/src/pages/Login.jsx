import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { Zap, LogIn } from "lucide-react";

export default function Login() {
  const { login } = useAuth();
  const [email, setEmail] = useState("admin@scalper.x");
  const [password, setPassword] = useState("admin123");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErr(""); setBusy(true);
    try { await login(email, password); }
    catch (e) { setErr(e.response?.data?.message || "Login failed"); }
    finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen grid-bg bg-ink-900 grid place-items-center px-4">
      <form onSubmit={submit} className="glass rounded-2xl p-8 w-full max-w-md shadow-neon animate-in">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-neon-blue to-neon-cyan grid place-items-center shadow-neon">
            <Zap className="text-ink-900" size={22} />
          </div>
          <div>
            <h1 className="font-display text-2xl text-white tracking-wider">SCALPER<span className="text-neon-blue">/</span>X</h1>
            <p className="text-xs text-neon-cyan/60 tracking-widest">EMA 9/21 × STOCHASTIC</p>
          </div>
        </div>
        <h2 className="text-white/80 mb-4 text-sm tracking-wide">SIGN IN</h2>
        {err && <div className="mb-3 text-neon-red text-sm bg-neon-red/10 rounded-lg px-3 py-2">{err}</div>}
        <Field label="Email" type="email" value={email} onChange={setEmail} />
        <Field label="Password" type="password" value={password} onChange={setPassword} />
        <button disabled={busy}
          className="w-full mt-2 bg-neon-blue text-ink-900 font-bold py-3 rounded-xl flex items-center justify-center gap-2 hover:shadow-neon transition disabled:opacity-60">
          <LogIn size={18} /> {busy ? "AUTHENTICATING…" : "ENTER TERMINAL"}
        </button>
        <p className="text-center text-white/40 text-sm mt-4">
          No account? <Link to="/register" className="text-neon-cyan">Create one</Link>
        </p>
        <p className="text-center text-white/25 text-xs mt-3">Demo: admin@scalper.x / admin123 (run <code>npm run seed</code>)</p>
      </form>
    </div>
  );
}

function Field({ label, ...props }) {
  return (
    <label className="block mb-3">
      <span className="text-xs text-white/50 tracking-wide">{label}</span>
      <input {...props} onChange={(e) => props.onChange(e.target.value)}
        className="w-full mt-1 bg-ink-800 border border-neon-blue/20 rounded-lg px-3 py-2.5 text-white outline-none focus:border-neon-blue focus:shadow-neon transition" />
    </label>
  );
}
