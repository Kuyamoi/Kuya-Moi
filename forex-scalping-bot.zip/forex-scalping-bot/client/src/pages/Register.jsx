import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { Zap, UserPlus } from "lucide-react";

export default function Register() {
  const { register } = useAuth();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    setErr(""); setBusy(true);
    try { await register(form.name, form.email, form.password); }
    catch (e) { setErr(e.response?.data?.message || "Registration failed"); }
    finally { setBusy(false); }
  };

  return (
    <div className="min-h-screen grid-bg bg-ink-900 grid place-items-center px-4">
      <form onSubmit={submit} className="glass rounded-2xl p-8 w-full max-w-md shadow-neon animate-in">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-neon-yellow to-neon-blue grid place-items-center shadow-neon-y">
            <Zap className="text-ink-900" size={22} />
          </div>
          <h1 className="font-display text-2xl text-white tracking-wider">SCALPER<span className="text-neon-yellow">/</span>X</h1>
        </div>
        <h2 className="text-white/80 mb-4 text-sm tracking-wide">CREATE ACCOUNT</h2>
        {err && <div className="mb-3 text-neon-red text-sm bg-neon-red/10 rounded-lg px-3 py-2">{err}</div>}
        <Field label="Name" value={form.name} onChange={set("name")} />
        <Field label="Email" type="email" value={form.email} onChange={set("email")} />
        <Field label="Password" type="password" value={form.password} onChange={set("password")} />
        <button disabled={busy}
          className="w-full mt-2 bg-neon-yellow text-ink-900 font-bold py-3 rounded-xl flex items-center justify-center gap-2 hover:shadow-neon-y transition disabled:opacity-60">
          <UserPlus size={18} /> {busy ? "CREATING…" : "CREATE ACCOUNT"}
        </button>
        <p className="text-center text-white/40 text-sm mt-4">
          Have an account? <Link to="/login" className="text-neon-cyan">Sign in</Link>
        </p>
      </form>
    </div>
  );
}

function Field({ label, ...props }) {
  return (
    <label className="block mb-3">
      <span className="text-xs text-white/50 tracking-wide">{label}</span>
      <input {...props} onChange={(e) => props.onChange(e.target.value)}
        className="w-full mt-1 bg-ink-800 border border-neon-blue/20 rounded-lg px-3 py-2.5 text-white outline-none focus:border-neon-yellow transition" />
    </label>
  );
}
