import { useEffect, useRef } from "react";

/**
 * TradingViewChart — embeds the official TradingView advanced chart widget
 * (loaded via tv.js in index.html). Shows live candlesticks for the selected
 * pair with EMA 9/21 + Stochastic studies pre-applied.
 */
export default function TradingViewChart({ pair = "EUR/USD" }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!window.TradingView || !ref.current) return;
    ref.current.innerHTML = "";
    const symbol = "FX:" + pair.replace("/", "");
    // eslint-disable-next-line no-new
    new window.TradingView.widget({
      container_id: ref.current.id,
      symbol,
      interval: "1",
      theme: "dark",
      style: "1",
      locale: "en",
      autosize: true,
      hide_side_toolbar: false,
      studies: ["MAExp@tv-basicstudies", "MAExp@tv-basicstudies", "Stochastic@tv-basicstudies"],
      overrides: { "paneProperties.background": "#05070f", "paneProperties.vertGridProperties.color": "#0f1525" },
    });
  }, [pair]);

  return <div id="tv_chart" ref={ref} className="w-full h-[420px] rounded-xl overflow-hidden" />;
}
