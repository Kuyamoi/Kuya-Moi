import { useState } from "react";
import api from "../api/client.js";
import { LineChart, Line, ResponsiveContainer, YAxis, Tooltip } from "recharts";
import { Play } from "lucide-react";

/** Runs a backtest on the backend and renders the equity curve + summary. */
export default function BacktestPanel({ pair, settings }) {
  const [report, setReport] = useState(null);
  const [busy, setBusy] = useState(false);

  const run = async () => {
    setBusy(true);
    try {
      const { data } = await api.post("/backtest", { pair, ...settings });
      setReport(data);
    } finally { setBusy(false); }
  };

  return (
    <div>
      <button onClick={run} disabled={busy}
        className="w-full mb-3 bg-neon-yellow text-ink-900 font-bold py-2.5 rounded-xl flex items-center justify-center gap-2 hover:shadow-neon-y transition">
        <Play size={16} /> {busy ? "RUNNING…" : `BACKTEST ${pair}`}
      </button>

      {report && (
        <div className="animate-in">
          <div className="grid grid-cols-3 gap-2 mb-3 text-center">
            <Mini label="Win Rate" value={`${report.summary.winRate}%`} />
            <Mini label="Net P/L" value={`$${report.summary.netPnl}`} tone={report.summary.netPnl >= 0 ? "up" : "down"} />
            <Mini label="Trades" value={report.summary.totalTrades} />
            <Mini label="Pips" value={report.summary.totalPips} />
            <Mini label="Profit Factor" value={report.summary.profitFactor} />
            <Mini label="Max DD" value={`$${report.summary.maxDrawdown}`} tone="down" />
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <LineChart data={report.equityCurve}>
              <YAxis domain={["auto", "auto"]} hide />
              <Tooltip contentStyle={{ background: "#0a0e1a", border: "1px solid #00d4ff44", borderRadius: 8 }} />
              <Line type="monotone" dataKey="equity" stroke="#22f0ff" dot={false} strokeWidth={1.6} isAnimationActive={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}

const Mini = ({ label, value, tone }) => (
  <div className="bg-ink-800/70 rounded-lg py-2">
    <div className="text-[10px] text-white/40">{label}</div>
    <div className={`font-display font-bold ${tone === "up" ? "text-neon-green" : tone === "down" ? "text-neon-red" : "text-white"}`}>{value}</div>
  </div>
);
