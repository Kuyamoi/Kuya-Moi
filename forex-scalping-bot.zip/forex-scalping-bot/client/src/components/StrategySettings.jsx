import { useState } from "react";
import api from "../api/client.js";
import { Save } from "lucide-react";

const STRAT = [["emaFast","EMA Fast"],["emaSlow","EMA Slow"],["stochK","Stoch %K"],["stochD","Stoch %D"],["overbought","Overbought"],["oversold","Oversold"]];
const RISK = [["lotSize","Lot Size"],["riskPercent","Risk %"],["takeProfitPips","TP (pips)"],["stopLossPips","SL (pips)"],["trailingStopPips","Trailing (pips)"],["maxOpenTrades","Max Open"],["dailyLossLimit","Daily Loss $"]];

/** Strategy + risk control form, persisted to /api/settings. */
export default function StrategySettings({ settings, onSaved }) {
  const [form, setForm] = useState(settings || {});
  const [saving, setSaving] = useState(false);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = async () => {
    setSaving(true);
    try { const { data } = await api.put("/settings", form); onSaved?.(data); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-4">
      <Group title="STRATEGY" items={STRAT} form={form} set={set} />
      <Group title="RISK MANAGEMENT" items={RISK} form={form} set={set} accent />
      <label className="flex items-center gap-2 text-sm text-white/70">
        <input type="checkbox" checked={!!form.autoCloseLosing} onChange={(e) => set("autoCloseLosing", e.target.checked)} />
        Auto-close losing trades at stop loss
      </label>
      <button onClick={save} disabled={saving}
        className="w-full bg-neon-blue text-ink-900 font-bold py-2.5 rounded-xl flex items-center justify-center gap-2 hover:shadow-neon transition">
        <Save size={16} /> {saving ? "SAVING…" : "SAVE SETTINGS"}
      </button>
    </div>
  );
}

function Group({ title, items, form, set, accent }) {
  return (
    <div>
      <div className={`text-[11px] tracking-widest mb-2 ${accent ? "text-neon-yellow/70" : "text-neon-cyan/70"}`}>{title}</div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        {items.map(([k, label]) => (
          <label key={k} className="block">
            <span className="text-[10px] text-white/40">{label}</span>
            <input type="number" value={form[k] ?? ""} onChange={(e) => set(k, +e.target.value)}
              className="w-full bg-ink-800 border border-white/10 rounded-lg px-2 py-1.5 text-white text-sm outline-none focus:border-neon-blue" />
          </label>
        ))}
      </div>
    </div>
  );
}
