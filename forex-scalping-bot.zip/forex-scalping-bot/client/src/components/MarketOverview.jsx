import { useEffect, useRef, useState } from "react";

/** Live multi-pair price ticker with up/down flash animation. */
export default function MarketOverview({ pairs, ticks, active, onSelect }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
      {pairs.map((p) => <PairTile key={p} pair={p} price={ticks[p]} active={p === active} onSelect={onSelect} />)}
    </div>
  );
}

function PairTile({ pair, price, active, onSelect }) {
  const prev = useRef(price);
  const [dir, setDir] = useState("");
  useEffect(() => {
    if (price == null) return;
    if (prev.current != null) setDir(price > prev.current ? "flash-up" : price < prev.current ? "flash-dn" : "");
    prev.current = price;
    const t = setTimeout(() => setDir(""), 600);
    return () => clearTimeout(t);
  }, [price]);

  const digits = pair.includes("JPY") ? 3 : 5;
  return (
    <button onClick={() => onSelect(pair)}
      className={`rounded-xl px-3 py-2.5 text-left border transition ${dir} ${
        active ? "border-neon-blue shadow-neon bg-neon-blue/5" : "border-white/5 bg-ink-800/60 hover:border-neon-blue/40"}`}>
      <div className="text-[11px] text-white/50">{pair}</div>
      <div className="font-mono text-white text-sm">{price != null ? price.toFixed(digits) : "—"}</div>
    </button>
  );
}
