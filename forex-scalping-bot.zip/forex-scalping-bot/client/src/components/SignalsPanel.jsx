import { TrendingUp, TrendingDown } from "lucide-react";

/** Active signals feed with animated entries. */
export default function SignalsPanel({ signals }) {
  if (!signals.length) return <Empty>Awaiting EMA crossover + Stochastic confirmation…</Empty>;
  return (
    <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
      {signals.map((s, i) => {
        const buy = s.type === "BUY";
        return (
          <div key={i} className="animate-in flex items-center gap-3 rounded-lg px-3 py-2 bg-ink-800/70 border border-white/5">
            <span className={`flex items-center gap-1 font-bold text-sm ${buy ? "text-neon-green" : "text-neon-red"}`}>
              {buy ? <TrendingUp size={15} /> : <TrendingDown size={15} />}{s.type}
            </span>
            <span className="text-white/70 text-sm">{s.pair}</span>
            <span className="font-mono text-white/50 text-xs">{s.price?.toFixed(s.pair?.includes("JPY") ? 3 : 5)}</span>
            <span className="ml-auto text-[10px] text-white/40">K{s.stoch?.k} D{s.stoch?.d}</span>
          </div>
        );
      })}
    </div>
  );
}

const Empty = ({ children }) => <div className="text-white/30 text-sm text-center py-8">{children}</div>;
