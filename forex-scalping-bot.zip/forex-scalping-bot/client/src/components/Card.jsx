export default function Card({ title, icon, accent, children, className = "" }) {
  return (
    <section className={`glass ${accent === "y" ? "glass-y" : ""} rounded-2xl p-4 ${className}`}>
      {title && (
        <header className="flex items-center justify-between mb-3">
          <h3 className="text-xs tracking-widest text-white/60 flex items-center gap-2 font-display">
            {icon} {title}
          </h3>
        </header>
      )}
      {children}
    </section>
  );
}
