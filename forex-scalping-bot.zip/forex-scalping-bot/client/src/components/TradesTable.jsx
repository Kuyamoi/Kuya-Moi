/** Recent trades table with P/L coloring. */
export default function TradesTable({ trades }) {
  if (!trades.length) return <div className="text-white/30 text-sm text-center py-8">No trades yet</div>;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-white/40 text-[11px] tracking-wider">
            <th className="text-left font-normal py-2">PAIR</th>
            <th className="text-left font-normal">SIDE</th>
            <th className="text-right font-normal">ENTRY</th>
            <th className="text-right font-normal">EXIT</th>
            <th className="text-right font-normal">PIPS</th>
            <th className="text-right font-normal">P/L</th>
            <th className="text-right font-normal">STATUS</th>
          </tr>
        </thead>
        <tbody className="font-mono">
          {trades.map((t) => (
            <tr key={t._id} className="border-t border-white/5">
              <td className="py-2 text-white/80">{t.pair}</td>
              <td className={t.direction === "BUY" ? "text-neon-green" : "text-neon-red"}>{t.direction}</td>
              <td className="text-right text-white/60">{t.entryPrice?.toFixed(t.pair?.includes("JPY") ? 3 : 5)}</td>
              <td className="text-right text-white/60">{t.exitPrice ? t.exitPrice.toFixed(t.pair?.includes("JPY") ? 3 : 5) : "—"}</td>
              <td className={`text-right ${t.pips >= 0 ? "text-neon-green" : "text-neon-red"}`}>{t.pips ?? "—"}</td>
              <td className={`text-right ${t.pnl >= 0 ? "text-neon-green" : "text-neon-red"}`}>{t.pnl != null ? `$${t.pnl}` : "—"}</td>
              <td className="text-right">
                <span className={`text-[10px] px-2 py-0.5 rounded ${t.status === "OPEN" ? "bg-neon-yellow/15 text-neon-yellow" : "bg-white/5 text-white/40"}`}>
                  {t.status === "OPEN" ? "OPEN" : t.closeReason}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
