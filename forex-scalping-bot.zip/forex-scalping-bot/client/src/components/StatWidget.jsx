/** Animated profit/loss + metric widget. */
export default function StatWidget({ label, value, sub, tone = "neutral" }) {
  const color = tone === "up" ? "text-neon-green" : tone === "down" ? "text-neon-red" : "text-white";
  return (
    <div className="glass rounded-xl px-4 py-3">
      <div className="text-[10px] tracking-widest text-white/40">{label}</div>
      <div className={`text-2xl font-display font-bold ${color}`}>{value}</div>
      {sub != null && <div className="text-[11px] text-white/40 mt-0.5">{sub}</div>}
    </div>
  );
}
