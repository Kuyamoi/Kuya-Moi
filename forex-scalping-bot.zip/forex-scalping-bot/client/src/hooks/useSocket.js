import { useEffect, useRef, useState } from "react";

/**
 * useSocket — connects to the backend WebSocket and exposes the latest
 * market data, indicator series and live signals per pair.
 */
export function useSocket() {
  const [connected, setConnected] = useState(false);
  const [ticks, setTicks] = useState({});       // pair -> price
  const [series, setSeries] = useState({});      // pair -> candle+indicator series
  const [signals, setSignals] = useState([]);    // recent signals
  const [tradeEvents, setTradeEvents] = useState([]);
  const wsRef = useRef(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const ws = new WebSocket(`${proto}://${location.host}/ws?token=${token || ""}`);
    wsRef.current = ws;

    ws.onopen = () => setConnected(true);
    ws.onclose = () => setConnected(false);
    ws.onmessage = (e) => {
      const { event, payload } = JSON.parse(e.data);
      if (event === "tick") setTicks((t) => ({ ...t, [payload.pair]: payload.price }));
      else if (event === "candle") setSeries((s) => ({ ...s, [payload.pair]: payload.series }));
      else if (event === "signal") setSignals((s) => [{ ...payload, at: Date.now() }, ...s].slice(0, 30));
      else if (event === "trade:open" || event === "trade:close")
        setTradeEvents((t) => [{ event, ...payload }, ...t].slice(0, 30));
    };
    return () => ws.close();
  }, []);

  return { connected, ticks, series, signals, tradeEvents };
}
