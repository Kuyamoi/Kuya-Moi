/** Central error handler — keeps controllers clean. */
export function notFound(req, res, next) {
  res.status(404).json({ message: `Route not found: ${req.originalUrl}` });
}

export function errorHandler(err, req, res, next) { // eslint-disable-line
  const code = res.statusCode && res.statusCode !== 200 ? res.statusCode : 500;
  console.error("[error]", err.message);
  res.status(code).json({
    message: err.message || "Server error",
    stack: process.env.NODE_ENV === "production" ? undefined : err.stack,
  });
}
