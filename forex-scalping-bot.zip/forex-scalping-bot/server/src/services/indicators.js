/**
 * indicators.js
 * Pure, dependency-free technical-indicator math used by the strategy engine.
 * All functions are deterministic and side-effect free so they can be unit tested
 * and reused by both the live engine and the backtester.
 */

/**
 * Exponential Moving Average.
 * @param {number[]} values - series of prices (typically closes)
 * @param {number} period
 * @returns {number[]} EMA series, same length as input
 */
export function ema(values, period) {
  const k = 2 / (period + 1);
  const out = [];
  let prev;
  for (let i = 0; i < values.length; i++) {
    prev = i === 0 ? values[0] : values[i] * k + prev * (1 - k);
    out.push(prev);
  }
  return out;
}

/**
 * Stochastic Oscillator (%K and %D).
 * %K = 100 * (close - lowestLow) / (highestHigh - lowestLow)
 * %D = simple moving average of %K
 * @param {{high:number,low:number,close:number}[]} candles
 * @param {number} kPeriod
 * @param {number} dPeriod
 * @returns {{k:(number|null)[], d:(number|null)[]}}
 */
export function stochastic(candles, kPeriod = 14, dPeriod = 3) {
  const k = [];
  for (let i = 0; i < candles.length; i++) {
    if (i < kPeriod - 1) { k.push(null); continue; }
    let hi = -Infinity, lo = Infinity;
    for (let j = i - kPeriod + 1; j <= i; j++) {
      hi = Math.max(hi, candles[j].high);
      lo = Math.min(lo, candles[j].low);
    }
    const c = candles[i].close;
    k.push(hi === lo ? 50 : ((c - lo) / (hi - lo)) * 100);
  }
  const d = k.map((_, i) => {
    if (i < kPeriod - 1 + dPeriod - 1) return null;
    const slice = k.slice(i - dPeriod + 1, i + 1);
    if (slice.some((v) => v === null)) return null;
    return slice.reduce((a, b) => a + b, 0) / dPeriod;
  });
  return { k, d };
}

/** Pip size helper — JPY pairs quote to 2 decimals, others to 4. */
export const pipSize = (pair) => (pair.includes("JPY") ? 0.01 : 0.0001);
