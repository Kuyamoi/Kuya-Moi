/**
 * strategy.js
 * The EMA 9/21 crossover + Stochastic Oscillator scalping strategy.
 *
 * BUY  : EMA9 crosses ABOVE EMA21  AND  Stochastic %K crosses above %D while
 *        emerging from the oversold zone (K below the oversold threshold).
 * SELL : EMA9 crosses BELOW EMA21  AND  Stochastic %K crosses below %D while
 *        coming out of the overbought zone (K above the overbought threshold).
 *
 * The function is pure: give it candles + config, it returns the signal for the
 * most recent candle (or null). Both the live engine and backtester call this.
 */
import { ema, stochastic } from "./indicators.js";

export const DEFAULT_STRATEGY = {
  emaFast: 9,
  emaSlow: 21,
  stochK: 14,
  stochD: 3,
  overbought: 80,
  oversold: 20,
  confirmBars: 3,
};

/**
 * Evaluate the strategy on a candle series.
 * @param {{open,high,low,close,time}[]} candles
 * @param {object} cfg - strategy config (merged with defaults by caller)
 * @returns {null | {type:'BUY'|'SELL', price:number, ema:{fast,slow}, stoch:{k,d}, reason:string}}
 */
export function evaluateStrategy(candles, cfg = DEFAULT_STRATEGY) {
  const need = cfg.emaSlow + cfg.stochK + cfg.stochD + 2;
  if (candles.length < need) return null;

  const closes = candles.map((c) => c.close);
  const fast = ema(closes, cfg.emaFast);
  const slow = ema(closes, cfg.emaSlow);
  const { k, d } = stochastic(candles, cfg.stochK, cfg.stochD);

  const i = candles.length - 1;
  const kNow = k[i], dNow = d[i];
  if (kNow == null || dNow == null) return null;

  // EMA crossover must occur on the latest closed candle (primary trigger)
  const emaCrossUp = fast[i - 1] <= slow[i - 1] && fast[i] > slow[i];
  const emaCrossDn = fast[i - 1] >= slow[i - 1] && fast[i] < slow[i];
  if (!emaCrossUp && !emaCrossDn) return null;

  // Stochastic confirmation.
  // We confirm the EMA trigger with the oscillator in two ways:
  //   (a) direction agreement: %K above %D for longs, below for shorts;
  //   (b) "room to run": not already exhausted in the opposite extreme
  //       (don't buy when already overbought; don't sell when already oversold).
  // A bonus flag marks the textbook case where the %K/%D cross also happened
  // inside the oversold/overbought zone within a short lookback window.
  const confirmBars = cfg.confirmBars ?? 3;

  const recentStochCross = (up) => {
    for (let j = i; j > i - confirmBars && j > 0; j--) {
      if (k[j - 1] == null || d[j - 1] == null) continue;
      const crossed = up ? k[j - 1] <= d[j - 1] && k[j] > d[j]
                         : k[j - 1] >= d[j - 1] && k[j] < d[j];
      const inZone = up ? k[j] < cfg.oversold + 25 : k[j] > cfg.overbought - 25;
      if (crossed && inZone) return true;
    }
    return false;
  };

  const bullishOk = kNow >= dNow && kNow < cfg.overbought;   // momentum up, not exhausted
  const bearishOk = kNow <= dNow && kNow > cfg.oversold;     // momentum down, not exhausted

  if (emaCrossUp && bullishOk) {
    const textbook = recentStochCross(true);
    return {
      type: "BUY",
      price: candles[i].close,
      ema: { fast: fast[i], slow: slow[i] },
      stoch: { k: +kNow.toFixed(2), d: +dNow.toFixed(2) },
      reason: textbook
        ? "EMA9>EMA21 + Stoch %K crossed above %D from oversold zone"
        : "EMA9>EMA21 + Stoch %K above %D (bullish momentum, not overbought)",
    };
  }
  if (emaCrossDn && bearishOk) {
    const textbook = recentStochCross(false);
    return {
      type: "SELL",
      price: candles[i].close,
      ema: { fast: fast[i], slow: slow[i] },
      stoch: { k: +kNow.toFixed(2), d: +dNow.toFixed(2) },
      reason: textbook
        ? "EMA9<EMA21 + Stoch %K crossed below %D from overbought zone"
        : "EMA9<EMA21 + Stoch %K below %D (bearish momentum, not oversold)",
    };
  }
  return null;
}

/** Build the indicator overlays for charting a whole series at once. */
export function computeSeries(candles, cfg = DEFAULT_STRATEGY) {
  const closes = candles.map((c) => c.close);
  const fast = ema(closes, cfg.emaFast);
  const slow = ema(closes, cfg.emaSlow);
  const { k, d } = stochastic(candles, cfg.stochK, cfg.stochD);
  return candles.map((c, i) => ({
    time: c.time, open: c.open, high: c.high, low: c.low, close: c.close,
    emaFast: fast[i], emaSlow: slow[i], k: k[i], d: d[i],
  }));
}
