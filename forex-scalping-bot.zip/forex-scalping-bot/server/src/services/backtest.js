/**
 * backtest.js
 * Runs the strategy over a historical candle series and reports performance.
 * Uses the SAME evaluateStrategy() as live trading, so results are consistent.
 */
import { evaluateStrategy, DEFAULT_STRATEGY } from "./strategy.js";
import { pipSize } from "./indicators.js";

/**
 * @param {object[]} candles - historical OHLC candles (oldest -> newest)
 * @param {object} cfg - strategy + risk config
 * @returns {object} performance report + equity curve + trade list
 */
export function runBacktest(candles, cfg = {}) {
  const c = { ...DEFAULT_STRATEGY, takeProfitPips: 8, stopLossPips: 6, lotSize: 0.1, pair: "EUR/USD", ...cfg };
  const ps = pipSize(c.pair);
  const trades = [];
  let open = null;
  let equity = 10000;
  const curve = [];

  for (let i = 50; i < candles.length; i++) {
    const window = candles.slice(0, i + 1);
    const price = candles[i].close;

    // Manage an open position first
    if (open) {
      const hitTP = open.direction === "BUY" ? candles[i].high >= open.tp : candles[i].low <= open.tp;
      const hitSL = open.direction === "BUY" ? candles[i].low <= open.sl : candles[i].high >= open.sl;
      if (hitTP || hitSL) {
        const exit = hitTP ? open.tp : open.sl;
        const pips = (open.direction === "BUY" ? exit - open.entry : open.entry - exit) / ps;
        const pnl = +(pips * 10 * c.lotSize).toFixed(2);
        equity += pnl;
        trades.push({ ...open, exit, pips: +pips.toFixed(1), pnl, reason: hitTP ? "TP" : "SL" });
        open = null;
      }
    }

    // Look for a new entry
    if (!open) {
      const sig = evaluateStrategy(window, c);
      if (sig) {
        const entry = sig.price;
        open = {
          direction: sig.type, entry,
          tp: sig.type === "BUY" ? entry + c.takeProfitPips * ps : entry - c.takeProfitPips * ps,
          sl: sig.type === "BUY" ? entry - c.stopLossPips * ps : entry + c.stopLossPips * ps,
        };
      }
    }
    curve.push({ i, equity: +equity.toFixed(2) });
  }

  const wins = trades.filter((t) => t.pnl > 0);
  const losses = trades.filter((t) => t.pnl <= 0);
  const grossWin = wins.reduce((a, t) => a + t.pnl, 0);
  const grossLoss = Math.abs(losses.reduce((a, t) => a + t.pnl, 0));

  return {
    summary: {
      totalTrades: trades.length,
      wins: wins.length,
      losses: losses.length,
      winRate: trades.length ? +((wins.length / trades.length) * 100).toFixed(1) : 0,
      netPnl: +(equity - 10000).toFixed(2),
      totalPips: +trades.reduce((a, t) => a + t.pips, 0).toFixed(1),
      profitFactor: grossLoss ? +(grossWin / grossLoss).toFixed(2) : grossWin > 0 ? Infinity : 0,
      finalEquity: +equity.toFixed(2),
      maxDrawdown: maxDrawdown(curve),
    },
    equityCurve: curve,
    trades,
  };
}

function maxDrawdown(curve) {
  let peak = -Infinity, mdd = 0;
  for (const p of curve) {
    peak = Math.max(peak, p.equity);
    mdd = Math.max(mdd, peak - p.equity);
  }
  return +mdd.toFixed(2);
}
