/**
 * marketFeed.js
 * Produces a stream of candles per forex pair and emits them to subscribers.
 *
 * Two modes (env FEED_MODE):
 *   - "sim"          : built-in geometric-Brownian-motion tick engine (no API key).
 *                      Great for development, demos and deterministic backtests.
 *   - "alphavantage" : polls Alpha Vantage FX intraday (requires ALPHA_VANTAGE_KEY).
 *
 * To plug in a real broker websocket (OANDA, Binance, MT5 bridge), implement a new
 * start<Provider>() method that calls this.pushCandle(pair, candle) — everything
 * downstream (strategy, engine, ws broadcast) stays unchanged.
 */
import EventEmitter from "events";

export const PAIRS = ["EUR/USD", "GBP/USD", "USD/JPY", "AUD/USD", "USD/CHF", "USD/CAD"];

const SEED = {
  "EUR/USD": 1.0856, "GBP/USD": 1.2712, "USD/JPY": 156.42,
  "AUD/USD": 0.6634, "USD/CHF": 0.8951, "USD/CAD": 1.3689,
};

class MarketFeed extends EventEmitter {
  constructor() {
    super();
    this.mode = process.env.FEED_MODE || "sim";
    this.history = {};   // pair -> candle[]
    this.builders = {};  // pair -> in-progress candle state
    this.drifts = {};    // pair -> {drift, ttl}
    this.timer = null;
    for (const p of PAIRS) {
      this.history[p] = this._warmup(p, 120); // pre-fill so indicators are ready
      const last = this.history[p][this.history[p].length - 1].close;
      this.builders[p] = { o: last, h: last, l: last, c: last, n: 0 };
      this.drifts[p] = { drift: 0, ttl: 0 };
    }
  }

  getHistory(pair, limit = 200) {
    return (this.history[pair] || []).slice(-limit);
  }

  start() {
    if (this.timer) return;
    if (this.mode === "alphavantage") this._startAlphaVantage();
    else this._startSim();
    console.log(`[feed] started in "${this.mode}" mode`);
  }

  stop() { clearInterval(this.timer); this.timer = null; }

  // ---- simulated GBM feed ----
  _tick(pair) {
    const d = this.drifts[pair];
    if (d.ttl <= 0) { d.drift = (Math.random() - 0.5) * 0.00008; d.ttl = 40 + Math.random() * 120; }
    d.ttl--;
    const vol = 0.00022;
    const shock = (Math.random() - 0.5) * 2;
    const b = this.builders[pair];
    const px = b.c * (1 + d.drift + vol * shock);
    b.c = px; b.h = Math.max(b.h, px); b.l = Math.min(b.l, px); b.n++;
    return px;
  }

  _startSim() {
    const TICKS_PER_CANDLE = 6;
    this.timer = setInterval(() => {
      for (const pair of PAIRS) {
        this._tick(pair);
        const b = this.builders[pair];
        this.emit("tick", { pair, price: b.c });
        if (b.n >= TICKS_PER_CANDLE) {
          const candle = { time: Date.now(), open: b.o, high: b.h, low: b.l, close: b.c };
          this.pushCandle(pair, candle);
          this.builders[pair] = { o: b.c, h: b.c, l: b.c, c: b.c, n: 0 };
        }
      }
    }, 1000);
  }

  // ---- Alpha Vantage polling (1-min FX bars) ----
  _startAlphaVantage() {
    const key = process.env.ALPHA_VANTAGE_KEY;
    const poll = async () => {
      for (const pair of PAIRS) {
        const [from, to] = pair.split("/");
        try {
          const url = `https://www.alphavantage.co/query?function=FX_INTRADAY&from_symbol=${from}&to_symbol=${to}&interval=1min&apikey=${key}`;
          const res = await fetch(url);
          const json = await res.json();
          const series = json["Time Series FX (1min)"];
          if (!series) continue;
          const latest = Object.keys(series).sort().pop();
          const row = series[latest];
          this.pushCandle(pair, {
            time: new Date(latest).getTime(),
            open: +row["1. open"], high: +row["2. high"],
            low: +row["3. low"], close: +row["4. close"],
          });
        } catch (e) { console.error("[feed] alphavantage error", e.message); }
      }
    };
    poll();
    this.timer = setInterval(poll, 60_000); // free tier is rate-limited
  }

  /** Append a finalized candle and notify subscribers. The engine listens here. */
  pushCandle(pair, candle) {
    this.history[pair] = [...(this.history[pair] || []), candle].slice(-500);
    this.emit("candle", { pair, candle, history: this.history[pair] });
  }

  /** Build a believable warmup history so indicators are valid on first signal. */
  _warmup(pair, n) {
    let price = SEED[pair];
    const out = [];
    for (let i = 0; i < n; i++) {
      const o = price;
      price = price * (1 + (Math.random() - 0.5) * 0.0006);
      const h = Math.max(o, price) * (1 + Math.random() * 0.0002);
      const l = Math.min(o, price) * (1 - Math.random() * 0.0002);
      out.push({ time: Date.now() - (n - i) * 60000, open: o, high: h, low: l, close: price });
    }
    return out;
  }
}

// Singleton shared across the app
export const marketFeed = new MarketFeed();

// Convenience: expose pair list + history pair keys on the instance/class
marketFeed.constructor.PAIRS = PAIRS;
marketFeed.getHistoryPairs = () => PAIRS;
