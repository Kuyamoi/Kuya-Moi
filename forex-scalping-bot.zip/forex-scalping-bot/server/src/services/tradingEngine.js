/**
 * tradingEngine.js
 * The heart of auto-execution. Subscribes to the market feed, runs the strategy
 * for every user whose bot is enabled, opens paper trades, and manages open
 * positions (TP / SL / trailing stop / auto-close) against live ticks.
 *
 * Paper trading by default. To route orders to a real broker, implement
 * executeBrokerOrder() and call it from openTrade() — the surrounding risk
 * logic stays the same.
 */
import User from "../models/User.js";
import Settings from "../models/Settings.js";
import Trade from "../models/Trade.js";
import { marketFeed } from "./marketFeed.js";
import { evaluateStrategy, DEFAULT_STRATEGY } from "./strategy.js";
import { pipSize } from "./indicators.js";
import { notifyAll } from "./notify.js";

export class TradingEngine {
  /** @param {(event:string, payload:any)=>void} broadcast - push updates to websocket clients */
  constructor(broadcast) {
    this.broadcast = broadcast || (() => {});
    this.dailyLoss = {}; // userId -> loss accumulated today
    this._resetDailyAt = this._endOfDay();
  }

  start() {
    // New finalized candle -> look for entry signals
    marketFeed.on("candle", ({ pair, history }) => this._onCandle(pair, history));
    // Every tick -> manage open positions against the live price
    marketFeed.on("tick", ({ pair, price }) => this._onTick(pair, price));
    console.log("[engine] trading engine online");
  }

  _endOfDay() { const d = new Date(); d.setHours(23, 59, 59, 999); return d.getTime(); }

  _maybeResetDaily() {
    if (Date.now() > this._resetDailyAt) { this.dailyLoss = {}; this._resetDailyAt = this._endOfDay(); }
  }

  async _onCandle(pair, history) {
    this._maybeResetDaily();
    // Find users running the bot on this pair
    const users = await User.find({ botEnabled: true });
    for (const user of users) {
      const settings = (await Settings.findOne({ user: user._id })) || {};
      const cfg = { ...DEFAULT_STRATEGY, ...settings.toObject?.() };
      if (settings.pairs && !settings.pairs.includes(pair)) continue;

      // Daily loss limit guard
      if ((this.dailyLoss[user._id] || 0) >= (settings.dailyLossLimit ?? 300)) continue;

      // Max open trades guard
      const open = await Trade.countDocuments({ user: user._id, status: "OPEN" });
      if (open >= (settings.maxOpenTrades ?? 3)) continue;

      // Avoid duplicate position on the same pair
      const dupe = await Trade.findOne({ user: user._id, pair, status: "OPEN" });
      if (dupe) continue;

      const signal = evaluateStrategy(history, cfg);
      if (signal) await this.openTrade(user, settings, pair, signal);
    }
  }

  async openTrade(user, settings, pair, signal) {
    const ps = pipSize(pair);
    const dir = signal.type;
    const entry = signal.price;
    const tpPips = settings.takeProfitPips ?? 8;
    const slPips = settings.stopLossPips ?? 6;
    const tp = dir === "BUY" ? entry + tpPips * ps : entry - tpPips * ps;
    const sl = dir === "BUY" ? entry - slPips * ps : entry + slPips * ps;

    const trade = await Trade.create({
      user: user._id, pair, direction: dir, lotSize: settings.lotSize ?? 0.1,
      entryPrice: entry, takeProfit: tp, stopLoss: sl,
      status: "OPEN", signalReason: signal.reason, source: "bot",
    });

    this.broadcast("trade:open", trade);
    notifyAll(`${dir} ${pair}`, `Entry ${entry.toFixed(5)} | TP ${tp.toFixed(5)} | SL ${sl.toFixed(5)}\n${signal.reason}`);
    return trade;
  }

  async _onTick(pair, price) {
    const open = await Trade.find({ pair, status: "OPEN" });
    for (const t of open) {
      // Trailing stop: ratchet SL toward price once in profit
      const settings = await Settings.findOne({ user: t.user });
      const ps = pipSize(pair);
      if (settings?.trailingStopPips > 0) {
        const trail = settings.trailingStopPips * ps;
        if (t.direction === "BUY" && price - trail > t.stopLoss) { t.stopLoss = price - trail; await t.save(); }
        if (t.direction === "SELL" && price + trail < t.stopLoss) { t.stopLoss = price + trail; await t.save(); }
      }

      const hitTP = t.direction === "BUY" ? price >= t.takeProfit : price <= t.takeProfit;
      const hitSL = t.direction === "BUY" ? price <= t.stopLoss : price >= t.stopLoss;
      if (hitTP || hitSL) {
        await this.closeTrade(t, hitTP ? t.takeProfit : t.stopLoss, hitTP ? "TP" : "SL");
      }
    }
  }

  async closeTrade(trade, exitPrice, reason) {
    const ps = pipSize(trade.pair);
    const pips = (trade.direction === "BUY" ? exitPrice - trade.entryPrice : trade.entryPrice - exitPrice) / ps;
    // Simplified P/L: pip value ~ $10 per pip per standard lot (FX major approximation)
    const pnl = +(pips * 10 * (trade.lotSize ?? 0.1)).toFixed(2);

    trade.exitPrice = exitPrice;
    trade.pips = +pips.toFixed(1);
    trade.pnl = pnl;
    trade.status = "CLOSED";
    trade.closeReason = reason;
    trade.closedAt = new Date();
    await trade.save();

    // Update account balance + daily loss tracker
    const user = await User.findById(trade.user);
    if (user) { user.balance = +(user.balance + pnl).toFixed(2); await user.save(); }
    if (pnl < 0) this.dailyLoss[trade.user] = (this.dailyLoss[trade.user] || 0) + Math.abs(pnl);

    this.broadcast("trade:close", trade);
    notifyAll(`Closed ${trade.direction} ${trade.pair} (${reason})`, `${pips.toFixed(1)} pips | P/L $${pnl}`);
    return trade;
  }
}
