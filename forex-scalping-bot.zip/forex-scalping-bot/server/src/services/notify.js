/**
 * notify.js — Telegram + Email notifications for signals and trade events.
 * All channels are optional: if env vars are missing the calls become no-ops,
 * so the app runs fine with zero notification config.
 */
import nodemailer from "nodemailer";

export async function notifyTelegram(text) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return;
  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "Markdown" }),
    });
  } catch (e) { console.error("[notify] telegram", e.message); }
}

let transporter = null;
function mailer() {
  if (transporter) return transporter;
  if (!process.env.SMTP_HOST) return null;
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: +(process.env.SMTP_PORT || 587),
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  return transporter;
}

export async function notifyEmail(subject, text) {
  const t = mailer();
  if (!t || !process.env.ALERT_EMAIL_TO) return;
  try {
    await t.sendMail({ from: process.env.SMTP_USER, to: process.env.ALERT_EMAIL_TO, subject, text });
  } catch (e) { console.error("[notify] email", e.message); }
}

export async function notifyAll(title, body) {
  await Promise.all([notifyTelegram(`*${title}*\n${body}`), notifyEmail(title, body)]);
}
