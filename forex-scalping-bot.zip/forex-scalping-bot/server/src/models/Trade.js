import mongoose from "mongoose";

const tradeSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    pair: { type: String, required: true },
    direction: { type: String, enum: ["BUY", "SELL"], required: true },
    lotSize: Number,
    entryPrice: { type: Number, required: true },
    exitPrice: Number,
    takeProfit: Number,
    stopLoss: Number,
    pips: Number,
    pnl: Number,
    status: { type: String, enum: ["OPEN", "CLOSED"], default: "OPEN", index: true },
    closeReason: { type: String, enum: ["TP", "SL", "TRAIL", "MANUAL", null], default: null },
    signalReason: String,
    source: { type: String, enum: ["bot", "manual", "backtest"], default: "bot" },
    openedAt: { type: Date, default: Date.now },
    closedAt: Date,
  },
  { timestamps: true }
);

export default mongoose.model("Trade", tradeSchema);
