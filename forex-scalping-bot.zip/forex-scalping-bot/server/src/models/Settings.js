import mongoose from "mongoose";

/** Per-user strategy + risk configuration. One document per user. */
const settingsSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, unique: true },

    // Strategy parameters
    emaFast: { type: Number, default: 9 },
    emaSlow: { type: Number, default: 21 },
    stochK: { type: Number, default: 14 },
    stochD: { type: Number, default: 3 },
    overbought: { type: Number, default: 80 },
    oversold: { type: Number, default: 20 },

    // Pairs the bot watches
    pairs: { type: [String], default: ["EUR/USD", "GBP/USD", "USD/JPY"] },

    // Risk management
    lotSize: { type: Number, default: 0.1 },          // standard lots
    riskPercent: { type: Number, default: 1 },         // % of balance risked per trade
    takeProfitPips: { type: Number, default: 8 },
    stopLossPips: { type: Number, default: 6 },
    trailingStopPips: { type: Number, default: 0 },    // 0 = disabled
    maxOpenTrades: { type: Number, default: 3 },
    dailyLossLimit: { type: Number, default: 300 },    // currency units; halts bot when hit
    autoCloseLosing: { type: Boolean, default: true },

    // Notifications
    notifyTelegram: { type: Boolean, default: false },
    notifyEmail: { type: Boolean, default: false },
  },
  { timestamps: true }
);

export default mongoose.model("Settings", settingsSchema);
