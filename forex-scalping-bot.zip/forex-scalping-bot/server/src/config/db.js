import mongoose from "mongoose";

/** Connect to MongoDB. Retries are handled by mongoose's built-in buffering. */
export async function connectDB() {
  const uri = process.env.MONGO_URI || "mongodb://localhost:27017/forex_scalper";
  mongoose.set("strictQuery", true);
  await mongoose.connect(uri);
  console.log(`[db] connected: ${uri.replace(/\/\/.*@/, "//***@")}`);
}
