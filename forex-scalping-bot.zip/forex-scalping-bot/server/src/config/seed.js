/**
 * seed.js — create a demo admin user. Run: npm run seed
 */
import "dotenv/config";
import { connectDB } from "./db.js";
import User from "../models/User.js";
import Settings from "../models/Settings.js";
import mongoose from "mongoose";

await connectDB();
const email = "admin@scalper.x";
let user = await User.findOne({ email });
if (!user) {
  user = await User.create({ name: "Admin", email, password: "admin123", role: "admin", balance: 10000 });
  await Settings.create({ user: user._id });
  console.log("Seeded admin:", email, "/ password: admin123");
} else {
  console.log("Admin already exists:", email);
}
await mongoose.connection.close();
process.exit(0);
