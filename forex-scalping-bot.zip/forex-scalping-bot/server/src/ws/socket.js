/**
 * socket.js — WebSocket server for real-time push to the dashboard.
 * Broadcasts: live ticks, finalized candles + indicator overlays, and
 * trade open/close events from the trading engine.
 *
 * Auth: clients connect with ?token=<JWT>. Invalid tokens are rejected.
 */
import { WebSocketServer } from "ws";
import jwt from "jsonwebtoken";
import { marketFeed } from "../services/marketFeed.js";
import { computeSeries, evaluateStrategy, DEFAULT_STRATEGY } from "../services/strategy.js";

export function attachWebSocket(server) {
  const wss = new WebSocketServer({ server, path: "/ws" });

  wss.on("connection", (ws, req) => {
    const url = new URL(req.url, "http://x");
    const token = url.searchParams.get("token");
    try {
      if (token) jwt.verify(token, process.env.JWT_SECRET);
    } catch {
      ws.close(4001, "invalid token");
      return;
    }
    ws.isAlive = true;
    ws.on("pong", () => (ws.isAlive = true));
    send(ws, "hello", { pairs: marketFeed.getHistoryPairs?.() || [] });
  });

  // Heartbeat to drop dead connections
  const ping = setInterval(() => {
    wss.clients.forEach((ws) => {
      if (!ws.isAlive) return ws.terminate();
      ws.isAlive = false; ws.ping();
    });
  }, 30000);
  wss.on("close", () => clearInterval(ping));

  const broadcast = (event, payload) => {
    const msg = JSON.stringify({ event, payload, ts: Date.now() });
    wss.clients.forEach((c) => c.readyState === 1 && c.send(msg));
  };

  // Pipe market events to all clients
  marketFeed.on("tick", ({ pair, price }) => broadcast("tick", { pair, price }));
  marketFeed.on("candle", ({ pair, candle, history }) => {
    const series = computeSeries(history, DEFAULT_STRATEGY).slice(-200);
    const signal = evaluateStrategy(history, DEFAULT_STRATEGY);
    broadcast("candle", { pair, candle, series });
    if (signal) broadcast("signal", { pair, ...signal });
  });

  return { wss, broadcast };
}

function send(ws, event, payload) {
  if (ws.readyState === 1) ws.send(JSON.stringify({ event, payload, ts: Date.now() }));
}
