import { Router } from "express";
import { protect, adminOnly } from "../middleware/auth.js";
import { register, login, me, toggleBot } from "../controllers/authController.js";
import { listTrades, analytics, closeTrade } from "../controllers/tradeController.js";
import { getSettings, updateSettings } from "../controllers/settingsController.js";
import { backtest } from "../controllers/backtestController.js";
import { marketFeed } from "../services/marketFeed.js";
import User from "../models/User.js";
import Trade from "../models/Trade.js";

const r = Router();

// ---- Auth ----
r.post("/auth/register", register);
r.post("/auth/login", login);
r.get("/auth/me", protect, me);
r.post("/auth/bot", protect, toggleBot);

// ---- Market data ----
r.get("/market/pairs", (req, res) => res.json(marketFeed.constructor.PAIRS || []));
r.get("/market/:pair/history", (req, res) => {
  const pair = decodeURIComponent(req.params.pair);
  res.json(marketFeed.getHistory(pair, +(req.query.limit || 200)));
});

// ---- Trades & analytics ----
r.get("/trades", protect, listTrades);
r.get("/trades/analytics", protect, analytics);
r.post("/trades/:id/close", protect, closeTrade);

// ---- Settings (strategy + risk) ----
r.get("/settings", protect, getSettings);
r.put("/settings", protect, updateSettings);

// ---- Backtesting ----
r.post("/backtest", protect, backtest);

// ---- Admin panel ----
r.get("/admin/users", protect, adminOnly, async (req, res) => {
  res.json(await User.find().select("-password").sort({ createdAt: -1 }));
});
r.get("/admin/stats", protect, adminOnly, async (req, res) => {
  res.json({
    users: await User.countDocuments(),
    openTrades: await Trade.countDocuments({ status: "OPEN" }),
    closedTrades: await Trade.countDocuments({ status: "CLOSED" }),
    botsRunning: await User.countDocuments({ botEnabled: true }),
  });
});

// ---- Health ----
r.get("/health", (req, res) => res.json({ status: "ok", uptime: process.uptime() }));

export default r;
