/**
 * index.js — application entry point.
 * Wires together Express (REST), the WebSocket server, MongoDB, the market feed,
 * and the auto-trading engine.
 */
import "dotenv/config";
import http from "http";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import rateLimit from "express-rate-limit";

import { connectDB } from "./config/db.js";
import routes from "./routes/index.js";
import { notFound, errorHandler } from "./middleware/error.js";
import { marketFeed } from "./services/marketFeed.js";
import { attachWebSocket } from "./ws/socket.js";
import { TradingEngine } from "./services/tradingEngine.js";

const app = express();

// ---- Security & parsing middleware ----
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "*", credentials: true }));
app.use(express.json({ limit: "2mb" }));
app.use(morgan(process.env.NODE_ENV === "production" ? "combined" : "dev"));
app.use("/api", rateLimit({ windowMs: 60_000, max: 300 })); // basic abuse protection

// ---- REST API ----
app.use("/api", routes);

// ---- Error handling ----
app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
const server = http.createServer(app);

async function bootstrap() {
  await connectDB();

  // Real-time websocket + broadcast fn
  const { broadcast } = attachWebSocket(server);

  // Start the market data feed and the auto-trading engine
  marketFeed.start();
  const engine = new TradingEngine(broadcast);
  engine.start();

  server.listen(PORT, () => console.log(`[server] API + WS listening on :${PORT}`));
}

bootstrap().catch((err) => {
  console.error("[fatal] failed to start:", err);
  process.exit(1);
});
