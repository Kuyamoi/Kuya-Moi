import { runBacktest } from "../services/backtest.js";
import { marketFeed } from "../services/marketFeed.js";

/**
 * Run a backtest. If no candles are supplied in the body, uses the in-memory
 * history for the requested pair (handy for quick demos).
 */
export async function backtest(req, res) {
  const { pair = "EUR/USD", candles, ...cfg } = req.body;
  const data = Array.isArray(candles) && candles.length
    ? candles
    : marketFeed.getHistory(pair, 500);
  if (!data.length) return res.status(400).json({ message: "No candle data available" });
  const report = runBacktest(data, { ...cfg, pair });
  res.json(report);
}
