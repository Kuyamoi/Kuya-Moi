import User from "../models/User.js";
import Settings from "../models/Settings.js";
import { signToken } from "../middleware/auth.js";

const shape = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role, balance: u.balance, botEnabled: u.botEnabled });

export async function register(req, res) {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ message: "All fields required" });
  if (await User.findOne({ email })) return res.status(409).json({ message: "Email already registered" });

  const user = await User.create({ name, email, password });
  await Settings.create({ user: user._id }); // default strategy + risk profile
  res.status(201).json({ token: signToken(user._id), user: shape(user) });
}

export async function login(req, res) {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).select("+password");
  if (!user || !(await user.matchPassword(password)))
    return res.status(401).json({ message: "Invalid email or password" });
  res.json({ token: signToken(user._id), user: shape(user) });
}

export async function me(req, res) {
  res.json({ user: shape(req.user) });
}

/** Toggle the auto-execution bot on/off for the current user. */
export async function toggleBot(req, res) {
  req.user.botEnabled = !!req.body.enabled;
  await req.user.save();
  res.json({ botEnabled: req.user.botEnabled });
}
