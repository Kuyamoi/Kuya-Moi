import Trade from "../models/Trade.js";

export async function listTrades(req, res) {
  const trades = await Trade.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(200);
  res.json(trades);
}

/** Aggregated analytics for the dashboard stats widgets. */
export async function analytics(req, res) {
  const trades = await Trade.find({ user: req.user._id, status: "CLOSED" });
  const wins = trades.filter((t) => t.pnl > 0);
  const net = trades.reduce((a, t) => a + (t.pnl || 0), 0);
  const pips = trades.reduce((a, t) => a + (t.pips || 0), 0);

  // Equity curve from closed trades
  let eq = req.user.balance - net;
  const curve = trades
    .slice()
    .sort((a, b) => new Date(a.closedAt) - new Date(b.closedAt))
    .map((t) => ({ t: t.closedAt, equity: +(eq += t.pnl).toFixed(2) }));

  res.json({
    totalTrades: trades.length,
    wins: wins.length,
    losses: trades.length - wins.length,
    winRate: trades.length ? +((wins.length / trades.length) * 100).toFixed(1) : 0,
    netPnl: +net.toFixed(2),
    totalPips: +pips.toFixed(1),
    balance: req.user.balance,
    openTrades: await Trade.countDocuments({ user: req.user._id, status: "OPEN" }),
    equityCurve: curve,
  });
}

/** Manually close an open trade. */
export async function closeTrade(req, res) {
  const trade = await Trade.findOne({ _id: req.params.id, user: req.user._id, status: "OPEN" });
  if (!trade) return res.status(404).json({ message: "Open trade not found" });
  trade.status = "CLOSED";
  trade.closeReason = "MANUAL";
  trade.exitPrice = req.body.price ?? trade.entryPrice;
  trade.closedAt = new Date();
  await trade.save();
  res.json(trade);
}
