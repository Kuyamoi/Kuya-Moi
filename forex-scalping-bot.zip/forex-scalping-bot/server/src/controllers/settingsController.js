import Settings from "../models/Settings.js";

export async function getSettings(req, res) {
  let s = await Settings.findOne({ user: req.user._id });
  if (!s) s = await Settings.create({ user: req.user._id });
  res.json(s);
}

export async function updateSettings(req, res) {
  const allowed = [
    "emaFast","emaSlow","stochK","stochD","overbought","oversold","pairs",
    "lotSize","riskPercent","takeProfitPips","stopLossPips","trailingStopPips",
    "maxOpenTrades","dailyLossLimit","autoCloseLosing","notifyTelegram","notifyEmail",
  ];
  const update = {};
  for (const k of allowed) if (k in req.body) update[k] = req.body[k];
  const s = await Settings.findOneAndUpdate(
    { user: req.user._id }, update, { new: true, upsert: true }
  );
  res.json(s);
}
