#requires -Version 5.1
<#
  build.ps1 — one-command build for Kuya Moi VPN.
  Produces:
    1. A single-file, self-contained EXE   (dist\KuyaMoiVPN.exe)
    2. An installer EXE (if Inno Setup is installed)  (dist\KuyaMoiVPN-Setup.exe)

  Prerequisites on the build machine:
    - .NET 8 SDK            https://dotnet.microsoft.com/download/dotnet/8.0
    - (optional) Inno Setup 6  https://jrsoftware.org/isdl.php   (for the installer)
#>
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$proj = Join-Path $root "src\KuyaMoiVPN\KuyaMoiVPN.csproj"
$dist = Join-Path $root "dist"
New-Item -ItemType Directory -Force -Path $dist | Out-Null

Write-Host "==> Restoring & publishing single-file EXE (win-x64)..." -ForegroundColor Cyan
dotnet publish $proj -c Release -r win-x64 --self-contained true `
  -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
  -o "$dist\app"

Copy-Item "$dist\app\KuyaMoiVPN.exe" "$dist\KuyaMoiVPN.exe" -Force
Write-Host "    Built: dist\KuyaMoiVPN.exe" -ForegroundColor Green

# Build installer if Inno Setup is present
$iscc = @(
  "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
  "${env:ProgramFiles}\Inno Setup 6\ISCC.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1

if ($iscc) {
  Write-Host "==> Building installer with Inno Setup..." -ForegroundColor Cyan
  & $iscc "$root\installer\KuyaMoiVPN.iss"
  Write-Host "    Built: dist\KuyaMoiVPN-Setup.exe" -ForegroundColor Green
} else {
  Write-Host "!! Inno Setup not found — skipped installer. EXE is ready in dist\." -ForegroundColor Yellow
}
