using System.Windows;
using KuyaMoiVPN.Services;

namespace KuyaMoiVPN;

public partial class App : Application
{
    /// <summary>True when launched with --minimized (used by "launch at startup").</summary>
    public static bool StartMinimized { get; private set; }

    protected override void OnStartup(StartupEventArgs e)
    {
        foreach (var arg in e.Args)
            if (arg.Equals("--minimized", System.StringComparison.OrdinalIgnoreCase))
                StartMinimized = true;

        Paths.EnsureCreated();
        base.OnStartup(e);
    }
}
