using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using KuyaMoiVPN.Models;
using KuyaMoiVPN.Services;

namespace KuyaMoiVPN.ViewModels;

public enum VpnState { Disconnected, Connecting, Connected, Error }

/// <summary>Top-level app state: server library, connection lifecycle, settings, live stats.</summary>
public class MainViewModel : ObservableObject
{
    private readonly WireGuardService _wg = new();
    private readonly DispatcherTimer _statsTimer;

    public ObservableCollection<ServerItemViewModel> Servers { get; } = new();
    public AppSettings Settings { get; private set; }

    public RelayCommand ConnectCommand { get; }
    public RelayCommand DisconnectCommand { get; }
    public RelayCommand ToggleCommand { get; }
    public RelayCommand ImportCommand { get; }
    public RelayCommand<ServerItemViewModel> DeleteServerCommand { get; }
    public RelayCommand<ServerItemViewModel> ToggleFavoriteCommand { get; }
    public RelayCommand SaveSettingsCommand { get; }

    public event Action<string>? ImportRequested;   // raised so the View can show a dialog

    public MainViewModel()
    {
        Settings = SettingsStore.Load();

        ConnectCommand = new RelayCommand(() => Connect(SelectedServer), () => SelectedServer != null && State != VpnState.Connected);
        DisconnectCommand = new RelayCommand(Disconnect, () => State is VpnState.Connected or VpnState.Connecting);
        ToggleCommand = new RelayCommand(() => { if (State == VpnState.Connected) Disconnect(); else Connect(SelectedServer); });
        ImportCommand = new RelayCommand(() => ImportRequested?.Invoke(string.Empty));
        DeleteServerCommand = new RelayCommand<ServerItemViewModel>(DeleteServer);
        ToggleFavoriteCommand = new RelayCommand<ServerItemViewModel>(ToggleFavorite);
        SaveSettingsCommand = new RelayCommand(SaveSettings);

        LoadServers();

        _statsTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
        _statsTimer.Tick += (_, _) => RefreshStats();
        _statsTimer.Start();

        if (!_wg.ToolsAvailable)
            StatusMessage = "WireGuard tools not found — install WireGuard for Windows to connect.";
    }

    // ---- bound state ----
    private VpnState _state = VpnState.Disconnected;
    public VpnState State { get => _state; private set { if (SetField(ref _state, value)) { OnPropertyChanged(nameof(IsConnected)); OnPropertyChanged(nameof(StateText)); Refresh(); } } }
    public bool IsConnected => State == VpnState.Connected;
    public string StateText => State switch
    {
        VpnState.Connected => "Connected",
        VpnState.Connecting => "Connecting…",
        VpnState.Error => "Error",
        _ => "Not connected",
    };

    private ServerItemViewModel? _selectedServer;
    public ServerItemViewModel? SelectedServer { get => _selectedServer; set { if (SetField(ref _selectedServer, value)) Refresh(); } }

    private string _statusMessage = "";
    public string StatusMessage { get => _statusMessage; set => SetField(ref _statusMessage, value); }

    private string _downText = "0 B";
    public string DownText { get => _downText; set => SetField(ref _downText, value); }
    private string _upText = "0 B";
    public string UpText { get => _upText; set => SetField(ref _upText, value); }
    private string _handshakeText = "—";
    public string HandshakeText { get => _handshakeText; set => SetField(ref _handshakeText, value); }

    private string _search = "";
    public string Search { get => _search; set { if (SetField(ref _search, value)) ApplyFilter(); } }

    public ObservableCollection<ServerItemViewModel> FilteredServers { get; } = new();

    // ---- server library ----
    private void LoadServers()
    {
        Servers.Clear();
        foreach (var s in ConfigStore.LoadAll())
            Servers.Add(new ServerItemViewModel(s));

        SelectedServer = Servers.FirstOrDefault(s => s.Model.Id == Settings.LastServerId) ?? Servers.FirstOrDefault();
        ApplyFilter();
    }

    private void ApplyFilter()
    {
        FilteredServers.Clear();
        var q = Search?.Trim() ?? "";
        foreach (var s in Servers)
        {
            if (q.Length == 0 ||
                s.Name.Contains(q, StringComparison.OrdinalIgnoreCase) ||
                s.Location.Contains(q, StringComparison.OrdinalIgnoreCase))
                FilteredServers.Add(s);
        }
    }

    public void ImportConfig(string pathOrText, string? name = null)
    {
        try
        {
            var profile = ConfigStore.Import(pathOrText, name);
            Servers.Add(new ServerItemViewModel(profile));
            ApplyFilter();
            StatusMessage = $"Imported “{profile.Name}”.";
        }
        catch (Exception ex) { StatusMessage = "Import failed: " + ex.Message; }
    }

    private void DeleteServer(ServerItemViewModel? s)
    {
        if (s == null) return;
        ConfigStore.Delete(s.Model);
        Servers.Remove(s);
        ApplyFilter();
    }

    private void ToggleFavorite(ServerItemViewModel? s)
    {
        if (s == null) return;
        ConfigStore.SetFavorite(s.Model, !s.IsFavorite);
        s.IsFavorite = s.Model.IsFavorite;
    }

    // ---- connection lifecycle ----
    public void Connect(ServerItemViewModel? server)
    {
        if (server == null) { StatusMessage = "Select a server first."; return; }
        try
        {
            State = VpnState.Connecting;
            StatusMessage = $"Connecting to {server.Name}…";
            _wg.Connect(server.Model, Settings);

            Settings.LastServerId = server.Model.Id;
            SettingsStore.Save(Settings);

            foreach (var s in Servers) s.IsConnected = false;
            server.IsConnected = true;
            State = VpnState.Connected;
            StatusMessage = $"Connected to {server.Name}.";
        }
        catch (Exception ex)
        {
            State = VpnState.Error;
            StatusMessage = "Connect failed: " + ex.Message;
            try { _wg.Disconnect(); } catch { }
        }
    }

    public void Disconnect()
    {
        try { _wg.Disconnect(); }
        catch (Exception ex) { StatusMessage = "Disconnect error: " + ex.Message; }
        foreach (var s in Servers) s.IsConnected = false;
        State = VpnState.Disconnected;
        DownText = UpText = "0 B"; HandshakeText = "—";
        StatusMessage = "Disconnected.";
    }

    private void RefreshStats()
    {
        if (State != VpnState.Connected) return;
        var st = _wg.GetStats();
        DownText = Human(st.RxBytes);
        UpText = Human(st.TxBytes);
        HandshakeText = st.LastHandshake?.ToString("HH:mm:ss") ?? "—";
        if (!st.Connected && st.LastHandshake == null)
            StatusMessage = "Tunnel handshake pending…";
    }

    // ---- settings ----
    public void SaveSettings()
    {
        SettingsStore.Save(Settings);
        StartupService.Set(Settings.LaunchAtStartup, Settings.StartMinimized);
        StatusMessage = "Settings saved.";
    }

    public void AutoConnectIfEnabled()
    {
        if (!Settings.AutoConnectOnLaunch) return;
        var target = Servers.FirstOrDefault(s => s.Model.Id == (Settings.AutoConnectServerId ?? Settings.LastServerId))
                     ?? Servers.FirstOrDefault();
        if (target != null) { SelectedServer = target; Connect(target); }
    }

    private void Refresh()
    {
        ConnectCommand.RaiseCanExecuteChanged();
        DisconnectCommand.RaiseCanExecuteChanged();
    }

    private static string Human(long bytes)
    {
        string[] u = { "B", "KB", "MB", "GB", "TB" };
        double v = bytes; int i = 0;
        while (v >= 1024 && i < u.Length - 1) { v /= 1024; i++; }
        return $"{v:0.##} {u[i]}";
    }
}
