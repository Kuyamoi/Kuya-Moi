using KuyaMoiVPN.Models;

namespace KuyaMoiVPN.ViewModels;

/// <summary>Wraps a ServerProfile for binding in the server list.</summary>
public class ServerItemViewModel : ObservableObject
{
    public ServerProfile Model { get; }
    public ServerItemViewModel(ServerProfile model) { Model = model; }

    public string Name => Model.Name;
    public string Flag => Model.Flag;
    public string Location => Model.DisplayLocation;
    public string Endpoint => Model.Endpoint;

    private bool _isFavorite;
    public bool IsFavorite { get => Model.IsFavorite; set { Model.IsFavorite = value; SetField(ref _isFavorite, value); } }

    private bool _isConnected;
    public bool IsConnected { get => _isConnected; set => SetField(ref _isConnected, value); }

    private bool _isSelected;
    public bool IsSelected { get => _isSelected; set => SetField(ref _isSelected, value); }
}
