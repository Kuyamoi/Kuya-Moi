using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using KuyaMoiVPN.Services;
using KuyaMoiVPN.ViewModels;
using Forms = System.Windows.Forms;

namespace KuyaMoiVPN;

public partial class MainWindow : Window
{
    private readonly MainViewModel _vm = new();
    private Forms.NotifyIcon? _tray;

    public MainWindow()
    {
        InitializeComponent();
        DataContext = _vm;

        _vm.ImportRequested += _ => ImportConfigDialog();

        Loaded += OnLoaded;
        StateChanged += OnStateChanged;
        Closing += OnClosing;
    }

    private void OnLoaded(object? sender, RoutedEventArgs e)
    {
        SetupTray();
        if (App.StartMinimized && _vm.Settings.MinimizeToTray)
            Hide();
        _vm.AutoConnectIfEnabled();
    }

    // ---- system tray ----
    private void SetupTray()
    {
        _tray = new Forms.NotifyIcon
        {
            Text = "Kuya Moi VPN",
            Visible = true,
        };
        try
        {
            var exe = System.Diagnostics.Process.GetCurrentProcess().MainModule?.FileName;
            _tray.Icon = (exe != null ? System.Drawing.Icon.ExtractAssociatedIcon(exe) : null)
                         ?? System.Drawing.SystemIcons.Shield;
        }
        catch { _tray.Icon = System.Drawing.SystemIcons.Shield; }
        var menu = new Forms.ContextMenuStrip();
        menu.Items.Add("Open", null, (_, _) => ShowFromTray());
        menu.Items.Add("Connect / Disconnect", null, (_, _) => _vm.ToggleCommand.Execute(null));
        menu.Items.Add("Exit", null, (_, _) => { _tray!.Visible = false; Application.Current.Shutdown(); });
        _tray.ContextMenuStrip = menu;
        _tray.DoubleClick += (_, _) => ShowFromTray();
    }

    private void ShowFromTray()
    {
        Show();
        WindowState = WindowState.Normal;
        Activate();
    }

    private void OnStateChanged(object? sender, EventArgs e)
    {
        if (WindowState == WindowState.Minimized && _vm.Settings.MinimizeToTray)
            Hide();
    }

    private void OnClosing(object? sender, CancelEventArgs e)
    {
        // If a tunnel is up, make sure we don't leave the firewall locked down.
        if (_vm.IsConnected) _vm.Disconnect();
        _tray?.Dispose();
    }

    // ---- settings + actions ----
    private void OnSettingChanged(object sender, RoutedEventArgs e) => _vm.SaveSettings();

    private void OnFavoriteClick(object sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: ServerItemViewModel item })
            _vm.ToggleFavoriteCommand.Execute(item);
    }

    private void ImportConfigDialog()
    {
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Title = "Import WireGuard configuration",
            Filter = "WireGuard config (*.conf)|*.conf|All files (*.*)|*.*",
        };
        if (dlg.ShowDialog() == true)
            _vm.ImportConfig(dlg.FileName);
    }

    private void OnSplitTunnelClick(object sender, RoutedEventArgs e)
    {
        var win = new SplitTunnelWindow(_vm.Settings) { Owner = this };
        if (win.ShowDialog() == true)
            _vm.SaveSettings();
    }
}
