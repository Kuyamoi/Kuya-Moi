using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;
using KuyaMoiVPN.ViewModels;

namespace KuyaMoiVPN;

/// <summary>VpnState -> accent/green/red brush for the status dot and ring.</summary>
public class StateToBrushConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c) => value switch
    {
        VpnState.Connected => new SolidColorBrush(Color.FromRgb(0x22, 0xE0, 0xC8)),
        VpnState.Connecting => new SolidColorBrush(Color.FromRgb(0xFF, 0xC8, 0x4D)),
        VpnState.Error => new SolidColorBrush(Color.FromRgb(0xFF, 0x54, 0x70)),
        _ => new SolidColorBrush(Color.FromRgb(0x7E, 0x8B, 0xA3)),
    };
    public object ConvertBack(object v, Type t, object p, CultureInfo c) => Binding.DoNothing;
}

/// <summary>Connected -> "DISCONNECT", otherwise "CONNECT".</summary>
public class ConnectedToActionConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => (value is bool b && b) ? "DISCONNECT" : "CONNECT";
    public object ConvertBack(object v, Type t, object p, CultureInfo c) => Binding.DoNothing;
}

public class BoolToVisibilityConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => (value is bool b && b) ? Visibility.Visible : Visibility.Collapsed;
    public object ConvertBack(object v, Type t, object p, CultureInfo c)
        => v is Visibility vis && vis == Visibility.Visible;
}

public class FavoriteToGlyphConverter : IValueConverter
{
    public object Convert(object value, Type t, object p, CultureInfo c)
        => (value is bool b && b) ? "★" : "☆";
    public object ConvertBack(object v, Type t, object p, CultureInfo c) => Binding.DoNothing;
}
