using System;
using System.Text.RegularExpressions;

namespace KuyaMoiVPN.Models;

/// <summary>
/// One VPN endpoint the user can connect to. Backed by a WireGuard .conf file.
/// Country/City/Flag are optional display metadata, parsed from "# Key = Value"
/// comment lines that the server-tools scripts embed in generated configs.
/// </summary>
public class ServerProfile
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];
    public string Name { get; set; } = "Server";
    public string Country { get; set; } = "";      // ISO code e.g. "SG"
    public string City { get; set; } = "";
    public string Flag { get; set; } = "🌐";        // emoji flag for the list
    public string Endpoint { get; set; } = "";     // host:port (parsed from [Peer])
    public string ConfigPath { get; set; } = "";   // full path to the .conf on disk
    public bool IsFavorite { get; set; }

    /// <summary>Server host without the port — used by the kill switch allow-rule.</summary>
    public string EndpointHost => Endpoint.Contains(':') ? Endpoint[..Endpoint.LastIndexOf(':')] : Endpoint;

    /// <summary>A Windows-service / adapter safe tunnel name (<=15 chars, alnum).</summary>
    public string TunnelName
    {
        get
        {
            var raw = string.IsNullOrWhiteSpace(Name) ? "KuyaMoi" : Name;
            var clean = Regex.Replace(raw, "[^A-Za-z0-9_]", "");
            if (clean.Length == 0) clean = "KuyaMoi";
            return clean.Length > 15 ? clean[..15] : clean;
        }
    }

    public string DisplayLocation =>
        string.IsNullOrEmpty(City) ? Country : $"{City}, {Country}".Trim(',', ' ');
}
