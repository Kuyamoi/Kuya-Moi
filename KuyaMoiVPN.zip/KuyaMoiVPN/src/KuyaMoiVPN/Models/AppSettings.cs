using System.Collections.Generic;

namespace KuyaMoiVPN.Models;

/// <summary>Persisted user preferences (JSON in %ProgramData%\KuyaMoiVPN\settings.json).</summary>
public class AppSettings
{
    // Security
    public bool KillSwitch { get; set; } = true;          // block traffic if tunnel drops
    public bool AllowLanAccess { get; set; } = false;      // exclude LAN ranges so local devices stay reachable

    // Connection behaviour
    public bool AutoConnectOnLaunch { get; set; } = false;
    public bool LaunchAtStartup { get; set; } = false;
    public bool StartMinimized { get; set; } = false;
    public bool MinimizeToTray { get; set; } = true;
    public string? LastServerId { get; set; }
    public string? AutoConnectServerId { get; set; }      // null => use last server

    // Split tunneling (route based). Mode: "off" | "exclude" | "include"
    public string SplitTunnelMode { get; set; } = "off";
    public List<string> SplitTunnelCidrs { get; set; } = new();  // CIDRs to exclude/include

    // DNS override (optional). Empty => use the server's DNS from the config.
    public string CustomDns { get; set; } = "";
}
