using System;
using System.Linq;
using System.Windows;
using KuyaMoiVPN.Models;
using KuyaMoiVPN.Services;

namespace KuyaMoiVPN;

public partial class SplitTunnelWindow : Window
{
    private readonly AppSettings _settings;

    public SplitTunnelWindow(AppSettings settings)
    {
        InitializeComponent();
        _settings = settings;

        RbOff.IsChecked = _settings.SplitTunnelMode == "off";
        RbExclude.IsChecked = _settings.SplitTunnelMode == "exclude";
        RbInclude.IsChecked = _settings.SplitTunnelMode == "include";
        CidrBox.Text = string.Join(Environment.NewLine, _settings.SplitTunnelCidrs);
    }

    private void OnSave(object sender, RoutedEventArgs e)
    {
        _settings.SplitTunnelMode = RbExclude.IsChecked == true ? "exclude"
                                  : RbInclude.IsChecked == true ? "include" : "off";

        var cidrs = CidrBox.Text
            .Split(new[] { '\n', '\r', ',' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(s => s.Trim())
            .Where(s => s.Length > 0)
            .ToList();

        var invalid = cidrs.Where(c => !CidrTools.IsValidCidr(c)).ToList();
        if (invalid.Any())
        {
            MessageBox.Show("These entries are not valid CIDRs:\n\n" + string.Join("\n", invalid),
                "Split Tunneling", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        _settings.SplitTunnelCidrs = cidrs;
        DialogResult = true;
        Close();
    }

    private void OnCancel(object sender, RoutedEventArgs e) { DialogResult = false; Close(); }
}
