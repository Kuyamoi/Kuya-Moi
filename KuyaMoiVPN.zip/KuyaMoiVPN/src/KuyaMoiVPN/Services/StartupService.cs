using Microsoft.Win32;
using System.Diagnostics;

namespace KuyaMoiVPN.Services;

/// <summary>Toggles "launch at Windows login" via the per-user Run key.</summary>
public static class StartupService
{
    private const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string ValueName = "KuyaMoiVPN";

    public static void Set(bool enabled, bool minimized)
    {
        using var key = Registry.CurrentUser.OpenSubKey(RunKey, writable: true)
                        ?? Registry.CurrentUser.CreateSubKey(RunKey);
        if (key == null) return;
        if (enabled)
        {
            var exe = Process.GetCurrentProcess().MainModule?.FileName ?? "";
            key.SetValue(ValueName, $"\"{exe}\"{(minimized ? " --minimized" : "")}");
        }
        else
        {
            if (key.GetValue(ValueName) != null) key.DeleteValue(ValueName, throwOnMissingValue: false);
        }
    }

    public static bool IsEnabled()
    {
        using var key = Registry.CurrentUser.OpenSubKey(RunKey);
        return key?.GetValue(ValueName) != null;
    }
}
