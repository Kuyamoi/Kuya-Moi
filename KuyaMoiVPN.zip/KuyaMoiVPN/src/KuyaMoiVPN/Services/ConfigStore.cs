using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using KuyaMoiVPN.Models;

namespace KuyaMoiVPN.Services;

/// <summary>
/// Manages the library of WireGuard server configs. Each .conf in Paths.Tunnels
/// becomes a ServerProfile. Display metadata is read from "# Key = Value" comment
/// lines that the server-tools scripts add, e.g.:
///     # Name = Singapore #1
///     # Country = SG
///     # City = Singapore
///     # Flag = 🇸🇬
/// </summary>
public static class ConfigStore
{
    private static readonly Dictionary<string, string> FlagByCc = new(StringComparer.OrdinalIgnoreCase)
    {
        ["US"]="🇺🇸",["GB"]="🇬🇧",["UK"]="🇬🇧",["SG"]="🇸🇬",["JP"]="🇯🇵",["DE"]="🇩🇪",["FR"]="🇫🇷",
        ["NL"]="🇳🇱",["CA"]="🇨🇦",["AU"]="🇦🇺",["PH"]="🇵🇭",["HK"]="🇭🇰",["IN"]="🇮🇳",["KR"]="🇰🇷",
        ["BR"]="🇧🇷",["SE"]="🇸🇪",["CH"]="🇨🇭",["IT"]="🇮🇹",["ES"]="🇪🇸",["AE"]="🇦🇪",["ID"]="🇮🇩",
    };

    public static List<ServerProfile> LoadAll()
    {
        Paths.EnsureCreated();
        var list = new List<ServerProfile>();
        foreach (var file in Directory.GetFiles(Paths.Tunnels, "*.conf"))
        {
            try { list.Add(Parse(file)); }
            catch { /* skip malformed configs */ }
        }
        return list.OrderByDescending(s => s.IsFavorite).ThenBy(s => s.Name).ToList();
    }

    /// <summary>Import a config from raw text (pasted) or a file path; returns the new profile.</summary>
    public static ServerProfile Import(string rawTextOrPath, string? suggestedName = null)
    {
        string text = File.Exists(rawTextOrPath) ? File.ReadAllText(rawTextOrPath) : rawTextOrPath;
        if (!text.Contains("[Interface]") || !text.Contains("[Peer]"))
            throw new InvalidDataException("Not a valid WireGuard configuration (missing [Interface]/[Peer]).");

        var name = suggestedName
                   ?? ReadComment(text, "Name")
                   ?? (File.Exists(rawTextOrPath) ? Path.GetFileNameWithoutExtension(rawTextOrPath) : null)
                   ?? "Server " + DateTime.Now.ToString("HHmmss");

        var safe = Regex.Replace(name, "[^A-Za-z0-9_-]", "_");
        var dest = Path.Combine(Paths.Tunnels, safe + ".conf");
        int i = 1;
        while (File.Exists(dest)) dest = Path.Combine(Paths.Tunnels, $"{safe}_{i++}.conf");
        File.WriteAllText(dest, text);
        return Parse(dest);
    }

    public static void Delete(ServerProfile p)
    {
        if (File.Exists(p.ConfigPath)) File.Delete(p.ConfigPath);
    }

    public static void SetFavorite(ServerProfile p, bool fav)
    {
        var text = File.ReadAllText(p.ConfigPath);
        text = UpsertComment(text, "Favorite", fav ? "1" : "0");
        File.WriteAllText(p.ConfigPath, text);
        p.IsFavorite = fav;
    }

    public static ServerProfile Parse(string path)
    {
        var text = File.ReadAllText(path);
        var p = new ServerProfile
        {
            ConfigPath = path,
            Name = ReadComment(text, "Name") ?? Path.GetFileNameWithoutExtension(path),
            Country = ReadComment(text, "Country") ?? "",
            City = ReadComment(text, "City") ?? "",
            Endpoint = ReadKey(text, "Endpoint") ?? "",
            IsFavorite = ReadComment(text, "Favorite") == "1",
        };
        p.Flag = ReadComment(text, "Flag")
                 ?? (FlagByCc.TryGetValue(p.Country, out var f) ? f : "🌐");
        return p;
    }

    // ---- tiny INI/comment readers ----
    private static string? ReadKey(string text, string key)
    {
        var m = Regex.Match(text, $@"^\s*{key}\s*=\s*(.+?)\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
        return m.Success ? m.Groups[1].Value.Trim() : null;
    }

    private static string? ReadComment(string text, string key)
    {
        var m = Regex.Match(text, $@"^\s*#\s*{key}\s*=\s*(.+?)\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);
        return m.Success ? m.Groups[1].Value.Trim() : null;
    }

    private static string UpsertComment(string text, string key, string value)
    {
        var pattern = $@"^\s*#\s*{key}\s*=.*$";
        if (Regex.IsMatch(text, pattern, RegexOptions.Multiline | RegexOptions.IgnoreCase))
            return Regex.Replace(text, pattern, $"# {key} = {value}", RegexOptions.Multiline | RegexOptions.IgnoreCase);
        return $"# {key} = {value}\n" + text;
    }
}
