using System;
using System.IO;

namespace KuyaMoiVPN.Services;

/// <summary>Central file locations under %ProgramData%\KuyaMoiVPN.</summary>
public static class Paths
{
    public static string Root { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "KuyaMoiVPN");

    public static string Tunnels { get; } = Path.Combine(Root, "Tunnels");   // imported server .conf files
    public static string Active { get; } = Path.Combine(Root, "Active");     // effective conf actually installed
    public static string SettingsFile { get; } = Path.Combine(Root, "settings.json");

    public static void EnsureCreated()
    {
        Directory.CreateDirectory(Tunnels);
        Directory.CreateDirectory(Active);
    }
}
