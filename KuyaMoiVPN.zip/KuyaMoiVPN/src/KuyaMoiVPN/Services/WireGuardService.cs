using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using KuyaMoiVPN.Models;

namespace KuyaMoiVPN.Services;

public record TunnelStats(bool Connected, long RxBytes, long TxBytes, DateTime? LastHandshake);

/// <summary>
/// Wraps the official WireGuard for Windows tooling (wireguard.exe / wg.exe).
/// Connecting installs a Windows tunnel service from an "effective" config that
/// we generate by applying the user's split-tunnel and DNS preferences to the
/// imported server config.
/// </summary>
public class WireGuardService
{
    private string? _wireguardExe;
    private string? _wgExe;

    public string? ActiveTunnel { get; private set; }

    /// <summary>Locate wireguard.exe / wg.exe (bundled beside the app, Program Files, or PATH).</summary>
    public bool ToolsAvailable => ResolveTools();

    public string WireGuardExe => _wireguardExe ?? "wireguard.exe";

    private bool ResolveTools()
    {
        if (_wireguardExe != null && _wgExe != null) return true;
        var candidates = new[]
        {
            AppContext.BaseDirectory,
            Path.Combine(AppContext.BaseDirectory, "wireguard"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "WireGuard"),
        };
        foreach (var dir in candidates)
        {
            var wg = Path.Combine(dir, "wireguard.exe");
            var wgc = Path.Combine(dir, "wg.exe");
            if (File.Exists(wg)) _wireguardExe = wg;
            if (File.Exists(wgc)) _wgExe = wgc;
        }
        // Fall back to PATH.
        _wireguardExe ??= FindOnPath("wireguard.exe");
        _wgExe ??= FindOnPath("wg.exe");
        return _wireguardExe != null;
    }

    /// <summary>
    /// Connect to a server. Builds an effective config (applying split tunnel + DNS),
    /// installs it as a tunnel service, and engages the kill switch if requested.
    /// </summary>
    public void Connect(ServerProfile server, AppSettings settings)
    {
        if (!ResolveTools())
            throw new FileNotFoundException(
                "WireGuard tools were not found. Install WireGuard for Windows or let the Kuya Moi VPN installer add it.");

        Disconnect(); // ensure single active tunnel

        // The kill switch is enforced by WireGuard itself: a full-tunnel config
        // (AllowedIPs = 0.0.0.0/0, ::/0) makes the engine block any traffic that
        // would otherwise leak outside the tunnel. BuildEffectiveConfig applies that.
        var effective = BuildEffectiveConfig(File.ReadAllText(server.ConfigPath), settings);
        Paths.EnsureCreated();
        var activePath = Path.Combine(Paths.Active, server.TunnelName + ".conf");
        File.WriteAllText(activePath, effective);

        Run(WireGuardExe, $"/installtunnelservice \"{activePath}\"");
        ActiveTunnel = server.TunnelName;
    }

    public void Disconnect()
    {
        // Tear down whatever tunnel is active (ours or a leftover from a crash).
        var name = ActiveTunnel ?? DetectActiveTunnel();
        if (name != null)
            Run(WireGuardExe, $"/uninstalltunnelservice {name}");
        ActiveTunnel = null;
    }

    /// <summary>Poll transfer + handshake stats for the active tunnel via "wg show ... dump".</summary>
    public TunnelStats GetStats()
    {
        var name = ActiveTunnel;
        if (name == null || _wgExe == null) return new TunnelStats(false, 0, 0, null);

        var output = Run(_wgExe, $"show {name} dump", capture: true);
        if (string.IsNullOrWhiteSpace(output)) return new TunnelStats(false, 0, 0, null);

        // dump: first line = interface; subsequent lines = peers.
        // peer fields: pubkey psk endpoint allowed-ips latest-handshake rx tx keepalive
        var lines = output.Split('\n', StringSplitOptions.RemoveEmptyEntries);
        long rx = 0, tx = 0; DateTime? hs = null;
        for (int i = 1; i < lines.Length; i++)
        {
            var f = lines[i].Split('\t');
            if (f.Length < 8) continue;
            if (long.TryParse(f[4], out var hsUnix) && hsUnix > 0)
                hs = DateTimeOffset.FromUnixTimeSeconds(hsUnix).LocalDateTime;
            if (long.TryParse(f[5], out var r)) rx += r;
            if (long.TryParse(f[6], out var t)) tx += t;
        }
        bool connected = hs != null && (DateTime.Now - hs.Value).TotalSeconds < 180;
        return new TunnelStats(connected, rx, tx, hs);
    }

    /// <summary>True if a Kuya Moi tunnel service is currently registered.</summary>
    public string? DetectActiveTunnel()
    {
        try
        {
            var sc = Run("sc", "query state= all", capture: true) ?? "";
            var m = Regex.Match(sc, @"WireGuardTunnel\$(\S+)");
            return m.Success ? m.Groups[1].Value : null;
        }
        catch { return null; }
    }

    /// <summary>RFC1918 + link-local ranges, excluded when the user wants LAN access.</summary>
    private static readonly string[] LanRanges =
        { "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "169.254.0.0/16" };

    /// <summary>
    /// Produce the config we actually install, applying:
    ///   - Kill switch  -> force a full tunnel (0.0.0.0/0, ::/0) so WireGuard blocks leaks
    ///   - LAN access   -> exclude private ranges so local devices stay reachable
    ///   - Split tunnel -> exclude/include specific CIDRs
    ///   - DNS override
    /// Split-tunnel settings take precedence over the kill switch for the affected routes
    /// (you can't both exclude a route AND guarantee it's tunnelled).
    /// </summary>
    public static string BuildEffectiveConfig(string baseConfig, AppSettings settings)
    {
        var allowedIps = ComputeAllowedIps(settings);

        var sb = new StringBuilder();
        foreach (var rawLine in baseConfig.Replace("\r\n", "\n").Split('\n'))
        {
            var trimmed = rawLine.TrimStart();

            if (!string.IsNullOrWhiteSpace(settings.CustomDns) &&
                trimmed.StartsWith("DNS", StringComparison.OrdinalIgnoreCase) && trimmed.Contains('='))
            {
                sb.AppendLine($"DNS = {settings.CustomDns}");
                continue;
            }

            if (allowedIps != null &&
                trimmed.StartsWith("AllowedIPs", StringComparison.OrdinalIgnoreCase) && trimmed.Contains('='))
            {
                sb.AppendLine("AllowedIPs = " + allowedIps);
                continue;
            }

            sb.AppendLine(rawLine);
        }
        return sb.ToString();
    }

    /// <summary>Returns the AllowedIPs string to use, or null to keep the config's own value.</summary>
    private static string? ComputeAllowedIps(AppSettings settings)
    {
        var userCidrs = settings.SplitTunnelCidrs.Where(CidrTools.IsValidCidr).ToList();

        switch (settings.SplitTunnelMode)
        {
            case "include":
                // Tunnel ONLY these routes (kill switch can't apply to the rest).
                return userCidrs.Count > 0 ? string.Join(", ", userCidrs) : null;

            case "exclude":
            {
                var toExclude = new List<string>(userCidrs);
                if (settings.AllowLanAccess) toExclude.AddRange(LanRanges);
                return toExclude.Count > 0
                    ? string.Join(", ", CidrTools.ExcludeFromDefault(toExclude))
                    : FullTunnel(settings);
            }

            default: // "off"
                return FullTunnel(settings);
        }
    }

    /// <summary>Full tunnel for the kill switch, optionally carving out the LAN.</summary>
    private static string? FullTunnel(AppSettings settings)
    {
        if (settings.AllowLanAccess)
            return string.Join(", ", CidrTools.ExcludeFromDefault(new List<string>(LanRanges)));
        if (settings.KillSwitch)
            return "0.0.0.0/0, ::/0";   // force full tunnel so WireGuard blocks leaks
        return null;                     // leave the imported config's AllowedIPs untouched
    }

    // ---- process helpers ----
    private static string? Run(string exe, string args, bool capture = false)
    {
        var psi = new ProcessStartInfo(exe, args)
        {
            CreateNoWindow = true,
            UseShellExecute = false,
            RedirectStandardOutput = capture,
            RedirectStandardError = capture,
        };
        using var p = Process.Start(psi);
        if (p == null) return null;
        string? output = capture ? p.StandardOutput.ReadToEnd() : null;
        p.WaitForExit(15000);
        return output;
    }

    private static string? FindOnPath(string exe)
    {
        var path = Environment.GetEnvironmentVariable("PATH") ?? "";
        foreach (var dir in path.Split(Path.PathSeparator))
        {
            try { var full = Path.Combine(dir, exe); if (File.Exists(full)) return full; }
            catch { }
        }
        return null;
    }
}
