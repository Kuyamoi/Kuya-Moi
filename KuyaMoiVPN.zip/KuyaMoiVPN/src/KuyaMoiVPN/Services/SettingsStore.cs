using System.IO;
using System.Text.Json;
using KuyaMoiVPN.Models;

namespace KuyaMoiVPN.Services;

/// <summary>Loads/saves AppSettings as JSON.</summary>
public static class SettingsStore
{
    private static readonly JsonSerializerOptions Opts = new() { WriteIndented = true };

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(Paths.SettingsFile))
                return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(Paths.SettingsFile)) ?? new AppSettings();
        }
        catch { /* fall through to defaults */ }
        return new AppSettings();
    }

    public static void Save(AppSettings settings)
    {
        Paths.EnsureCreated();
        File.WriteAllText(Paths.SettingsFile, JsonSerializer.Serialize(settings, Opts));
    }
}
