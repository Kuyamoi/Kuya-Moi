using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Numerics;

namespace KuyaMoiVPN.Services;

/// <summary>
/// IPv4 CIDR maths for route-based split tunneling.
/// "Exclude" mode computes the set of routes that covers all of 0.0.0.0/0
/// EXCEPT the user's excluded subnets — this is how WireGuard implements
/// "send everything through the VPN except these addresses".
/// </summary>
public static class CidrTools
{
    private readonly record struct Range(uint Start, uint End);

    /// <summary>Full IPv4 space minus the excluded CIDRs, returned as a minimal CIDR list.</summary>
    public static List<string> ExcludeFromDefault(IEnumerable<string> excludeCidrs)
    {
        var excluded = excludeCidrs
            .Select(ParseV4)
            .Where(r => r.HasValue)
            .Select(r => r!.Value)
            .OrderBy(r => r.Start)
            .ToList();

        var result = new List<string>();
        uint cursor = 0;
        foreach (var ex in MergeRanges(excluded))
        {
            if (ex.Start > cursor)
                result.AddRange(RangeToCidrs(cursor, ex.Start - 1));
            cursor = ex.End == uint.MaxValue ? ex.End : ex.End + 1;
            if (ex.End == uint.MaxValue) { cursor = 0; break; }
        }
        if (cursor != 0 && cursor <= uint.MaxValue)
            result.AddRange(RangeToCidrs(cursor, uint.MaxValue));

        // Always keep IPv6 default so v6 doesn't leak; users on v4-only servers can ignore.
        result.Add("::/0");
        return result;
    }

    public static bool IsValidCidr(string cidr) => ParseV4(cidr) != null
        || cidr.Trim() == "::/0" || cidr.Contains(':'); // accept v6 loosely

    private static Range? ParseV4(string cidr)
    {
        try
        {
            cidr = cidr.Trim();
            var parts = cidr.Split('/');
            var ip = IPAddress.Parse(parts[0]);
            if (ip.AddressFamily != System.Net.Sockets.AddressFamily.InterNetwork) return null;
            int prefix = parts.Length > 1 ? int.Parse(parts[1]) : 32;
            uint addr = ToUInt(ip);
            uint mask = prefix == 0 ? 0 : uint.MaxValue << (32 - prefix);
            uint start = addr & mask;
            uint end = start | ~mask;
            return new Range(start, end);
        }
        catch { return null; }
    }

    private static IEnumerable<Range> MergeRanges(List<Range> ranges)
    {
        if (ranges.Count == 0) yield break;
        var cur = ranges[0];
        for (int i = 1; i < ranges.Count; i++)
        {
            var r = ranges[i];
            if (r.Start <= (cur.End == uint.MaxValue ? cur.End : cur.End + 1))
                cur = new Range(cur.Start, Math.Max(cur.End, r.End));
            else { yield return cur; cur = r; }
        }
        yield return cur;
    }

    private static IEnumerable<string> RangeToCidrs(uint start, uint end)
    {
        var list = new List<string>();
        ulong s = start;
        ulong e = end;            // use 64-bit so we can pass the 0xFFFFFFFF boundary safely
        while (s <= e)
        {
            // Largest CIDR block aligned to 's': limited by the number of trailing zero bits.
            int trailingZeros = s == 0 ? 32 : System.Numerics.BitOperations.TrailingZeroCount((uint)s);
            int maxAligned = trailingZeros;
            // Largest block that fits within the remaining range [s, e].
            ulong span = e - s + 1;
            int maxByCount = (int)Math.Floor(Math.Log2(span));
            int blockBits = Math.Min(maxAligned, maxByCount);
            int prefix = 32 - blockBits;
            list.Add($"{ToIp((uint)s)}/{prefix}");
            s += (ulong)1 << blockBits;
        }
        return list;
    }

    private static uint ToUInt(IPAddress ip)
    {
        var b = ip.GetAddressBytes();
        return ((uint)b[0] << 24) | ((uint)b[1] << 16) | ((uint)b[2] << 8) | b[3];
    }

    private static string ToIp(uint v)
        => $"{(v >> 24) & 0xFF}.{(v >> 16) & 0xFF}.{(v >> 8) & 0xFF}.{v & 0xFF}";
}
