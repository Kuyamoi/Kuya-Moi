# Kuya Moi VPN

A real Windows VPN client built on the WireGuard engine — the same architecture commercial apps like Surfshark and Mullvad use. Native WPF (.NET 8), dark UI, with a server list, kill switch, split tunneling, auto-connect, favorites and live transfer stats.

> **You own this.** It connects to **your** WireGuard servers (or any WireGuard config you import). The repo includes scripts to stand up a server on any VPS in minutes, so it's usable end-to-end.

---

## What it does

- **Server list** with country flags, search and favorites (★)
- **One-tap connect / disconnect** with a live status ring
- **Kill switch** — default-deny firewall lockdown so nothing leaks if the tunnel drops
- **Split tunneling** (route-based) — *exclude* IPs/subnets from the VPN, or tunnel *only* specific ones
- **Auto-connect** on launch and **launch at Windows startup**
- **System tray** with quick connect/disconnect
- **Live stats** — download/upload counters and last handshake time

## How it works

The app is a manager around the official WireGuard for Windows tooling:

1. You import a WireGuard `.conf` (one per server). Each becomes a server entry; country/city/flag come from `# Name = …` / `# Country = …` comment lines the server scripts add.
2. On **Connect**, the app builds an *effective* config (applying split-tunnel routes + DNS), then runs `wireguard.exe /installtunnelservice` to bring up a Windows tunnel service. Requires admin (the app manifest requests elevation).
3. The **kill switch** works the way the WireGuard engine intends: when enabled, the app installs a *full-tunnel* config (`AllowedIPs = 0.0.0.0/0, ::/0`), and WireGuard's own "block untunneled traffic" firewall rules then drop anything that would leak outside the tunnel. Turn on **Allow LAN access** to carve your local subnet back out (so printers/NAS stay reachable).
4. Stats come from parsing `wg show <tunnel> dump` on a timer.

```
KuyaMoiVPN/
├── build.ps1                     # one-command build -> dist\KuyaMoiVPN.exe (+ Setup.exe)
├── installer/KuyaMoiVPN.iss      # Inno Setup -> KuyaMoiVPN-Setup.exe
├── server-tools/
│   ├── setup-wireguard-server.sh # stand up a WireGuard server on a VPS
│   └── add-client.sh             # mint a client .conf to import
└── src/KuyaMoiVPN/
    ├── KuyaMoiVPN.csproj
    ├── app.manifest              # requireAdministrator
    ├── Models/                   # ServerProfile, AppSettings
    ├── Services/                 # WireGuard, KillSwitch, ConfigStore, CidrTools, Startup
    ├── ViewModels/               # MVVM (MainViewModel, commands)
    ├── MainWindow.xaml           # dashboard
    └── SplitTunnelWindow.xaml    # split-tunnel editor
```

---

## Build it (on Windows)

**Prerequisites**
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0)
- [WireGuard for Windows](https://www.wireguard.com/install/) (the app uses its engine)
- *(optional)* [Inno Setup 6](https://jrsoftware.org/isdl.php) to produce the installer

**One command** (from the project root, in PowerShell):
```powershell
./build.ps1
```
Output:
- `dist\KuyaMoiVPN.exe` — single-file, self-contained (no .NET needed on the target PC)
- `dist\KuyaMoiVPN-Setup.exe` — installer (only if Inno Setup is installed)

> The app is **not code-signed**, so SmartScreen will warn on first run (“More info → Run anyway”). For public distribution, sign the exe with an Authenticode certificate.

---

## Get a server (so you can actually connect)

On a fresh Ubuntu/Debian VPS (DigitalOcean, Vultr, Hetzner, etc.):
```bash
sudo bash setup-wireguard-server.sh
sudo bash add-client.sh my-laptop SG Singapore   # prints + writes my-laptop.conf
```
Copy `my-laptop.conf` to Windows → open Kuya Moi VPN → **Import config** → **Connect**.

Repeat `add-client.sh` on multiple VPSs in different regions to build out your server list.

---

## Notes & honest limitations

- **A VPN needs a server.** This is a client; it protects traffic by tunneling to an endpoint you control. There's no built-in free server network.
- **Split tunneling is route-based** (by IP/subnet). Per-application rules need a WFP kernel driver, which is out of scope here.
- **Kill switch** relies on WireGuard's full-tunnel "block untunneled traffic" firewall rules, which are active while the tunnel service is running; the app tears the tunnel down cleanly on disconnect and on exit. Note that a strict kill switch and split tunneling pull in opposite directions — excluded routes are, by definition, allowed outside the tunnel.
- Run as administrator — creating tunnel services and firewall rules requires it (handled by the manifest).
- This is provided for lawful use. You're responsible for compliance with local laws and your VPS provider's terms.

## License
MIT — see LICENSE.
