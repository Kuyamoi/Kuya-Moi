; Inno Setup script — builds KuyaMoiVPN-Setup.exe
; The installer also ensures WireGuard for Windows is present (the app shells out
; to wireguard.exe/wg.exe). We detect an existing install and otherwise prompt.

#define AppName "Kuya Moi VPN"
#define AppVersion "1.0.0"
#define AppPublisher "Kuya Moi"
#define AppExe "KuyaMoiVPN.exe"

[Setup]
AppId={{8E5B2A10-7C3D-4F2E-9A11-KUYAMOIVPN01}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppPublisher}
DefaultDirName={autopf}\KuyaMoiVPN
DefaultGroupName={#AppName}
UninstallDisplayIcon={app}\{#AppExe}
OutputDir=..\dist
OutputBaseFilename=KuyaMoiVPN-Setup
Compression=lzma2
SolidCompression=yes
PrivilegesRequired=admin
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "..\dist\KuyaMoiVPN.exe"; DestDir: "{app}"; Flags: ignoreversion
; If you choose to bundle WireGuard binaries, drop wireguard.exe/wg.exe in
; installer\wireguard\ and uncomment the next line:
; Source: "wireguard\*"; DestDir: "{app}\wireguard"; Flags: ignoreversion recursesubdirs

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{commondesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"

[Run]
Filename: "{app}\{#AppExe}"; Description: "Launch {#AppName}"; Flags: nowait postinstall skipifsilent

[Code]
function WireGuardInstalled(): Boolean;
begin
  Result := FileExists(ExpandConstant('{pf}\WireGuard\wireguard.exe'))
         or FileExists(ExpandConstant('{app}\wireguard\wireguard.exe'));
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if (CurStep = ssPostInstall) and (not WireGuardInstalled()) then
    MsgBox('Kuya Moi VPN uses the WireGuard engine.' + #13#10 +
           'Please install WireGuard for Windows from https://www.wireguard.com/install/ ' +
           'so the app can create tunnels.', mbInformation, MB_OK);
end;
