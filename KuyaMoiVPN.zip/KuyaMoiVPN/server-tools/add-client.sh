#!/usr/bin/env bash
# add-client.sh NAME [COUNTRY_CODE] [CITY]
# Generates a client .conf (with Kuya Moi metadata comments) and registers the
# client as a peer on the server. Copy the printed .conf to Windows and import it.
#
#   sudo bash add-client.sh my-laptop SG Singapore
set -euo pipefail

NAME="${1:?usage: add-client.sh NAME [COUNTRY] [CITY]}"
COUNTRY="${2:-}"
CITY="${3:-}"

WG_DIR=/etc/wireguard
WG_IF="${WG_IF:-wg0}"
WG_PORT="${WG_PORT:-51820}"
WG_NET="${WG_NET:-10.7.0}"
DNS="${DNS:-1.1.1.1}"

SERVER_PUB=$(cat "$WG_DIR/server_public.key")
PUBIP=$(curl -s https://api.ipify.org || echo "<server-ip>")

# Pick the next free client IP (.2 ... .254)
USED=$(grep -oE "${WG_NET}\.[0-9]+" "$WG_DIR/$WG_IF.conf" | awk -F. '{print $4}' | sort -n | tail -1)
NEXT=$(( ${USED:-1} + 1 ))
CLIENT_IP="${WG_NET}.${NEXT}"

CLIENT_PRIV=$(wg genkey)
CLIENT_PUB=$(echo "$CLIENT_PRIV" | wg pubkey)
PSK=$(wg genpsk)

# Register peer on the server (live + persisted)
wg set "$WG_IF" peer "$CLIENT_PUB" preshared-key <(echo "$PSK") allowed-ips "${CLIENT_IP}/32"
cat >> "$WG_DIR/$WG_IF.conf" <<PEER

[Peer]
# ${NAME}
PublicKey = ${CLIENT_PUB}
PresharedKey = ${PSK}
AllowedIPs = ${CLIENT_IP}/32
PEER

OUT="${NAME}.conf"
cat > "$OUT" <<CONF
# Name = ${NAME}
# Country = ${COUNTRY}
# City = ${CITY}
[Interface]
PrivateKey = ${CLIENT_PRIV}
Address = ${CLIENT_IP}/24
DNS = ${DNS}

[Peer]
PublicKey = ${SERVER_PUB}
PresharedKey = ${PSK}
Endpoint = ${PUBIP}:${WG_PORT}
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
CONF

echo "============================================================"
echo " Client config written: $(pwd)/${OUT}"
echo " Transfer it to Windows and use 'Import config' in Kuya Moi VPN."
echo "------------------------------------------------------------"
cat "$OUT"
echo "============================================================"
