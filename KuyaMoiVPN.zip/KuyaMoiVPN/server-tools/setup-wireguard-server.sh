#!/usr/bin/env bash
# setup-wireguard-server.sh
# Stand up a WireGuard VPN server on a fresh Ubuntu/Debian VPS so the Kuya Moi VPN
# Windows app has a real endpoint to connect to. Run as root.
#
#   sudo bash setup-wireguard-server.sh
#
# Outputs the server's public key + endpoint. Use add-client.sh to mint client
# configs that you import into the Windows app.
set -euo pipefail

WG_DIR=/etc/wireguard
WG_PORT="${WG_PORT:-51820}"
WG_NET="${WG_NET:-10.7.0}"          # server = .1, clients = .2, .3, ...
WG_IF="${WG_IF:-wg0}"

echo "==> Installing WireGuard..."
apt-get update -y
apt-get install -y wireguard qrencode iptables

echo "==> Enabling IP forwarding..."
sysctl -w net.ipv4.ip_forward=1
grep -q "net.ipv4.ip_forward=1" /etc/sysctl.conf || echo "net.ipv4.ip_forward=1" >> /etc/sysctl.conf

mkdir -p "$WG_DIR"; chmod 700 "$WG_DIR"
if [[ ! -f "$WG_DIR/server_private.key" ]]; then
  echo "==> Generating server keys..."
  wg genkey | tee "$WG_DIR/server_private.key" | wg pubkey > "$WG_DIR/server_public.key"
  chmod 600 "$WG_DIR/server_private.key"
fi

SERVER_PRIV=$(cat "$WG_DIR/server_private.key")
NIC=$(ip route | awk '/default/ {print $5; exit}')

cat > "$WG_DIR/$WG_IF.conf" <<CONF
[Interface]
Address = ${WG_NET}.1/24
ListenPort = ${WG_PORT}
PrivateKey = ${SERVER_PRIV}
PostUp   = iptables -A FORWARD -i ${WG_IF} -j ACCEPT; iptables -t nat -A POSTROUTING -o ${NIC} -j MASQUERADE
PostDown = iptables -D FORWARD -i ${WG_IF} -j ACCEPT; iptables -t nat -D POSTROUTING -o ${NIC} -j MASQUERADE
# Clients are appended below by add-client.sh
CONF
chmod 600 "$WG_DIR/$WG_IF.conf"

systemctl enable "wg-quick@${WG_IF}" >/dev/null 2>&1 || true
systemctl restart "wg-quick@${WG_IF}"

PUBIP=$(curl -s https://api.ipify.org || echo "<server-ip>")
echo
echo "============================================================"
echo " WireGuard server is up."
echo "   Endpoint:    ${PUBIP}:${WG_PORT}"
echo "   Public key:  $(cat "$WG_DIR/server_public.key")"
echo "   Interface:   ${WG_IF}  (subnet ${WG_NET}.0/24)"
echo
echo " Next: create a client config to import into Kuya Moi VPN:"
echo "   sudo bash add-client.sh my-laptop SG Singapore"
echo "============================================================"
